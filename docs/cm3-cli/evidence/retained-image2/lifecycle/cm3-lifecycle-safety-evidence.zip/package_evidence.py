"""Package and independently replay the local fixture evidence; no image operations."""
import csv
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

HERE = Path(__file__).resolve().parent
UPSTREAM = Path('/opt/data/kanban/workspaces/t_6c2ac45f/built-source')
for original, dest in [
    (UPSTREAM / 'packages/cm3-cli-board-support/README', HERE / 'source-context/board-support-README.txt'),
    (UPSTREAM / 'docs/cm3-cli/first-boot.md', HERE / 'source-context/first-boot.md'),
    (HERE / 'offline-input/evidence/hardware-matrix.tsv', HERE / 'source-context/hardware-matrix.tsv'),
    (HERE / 'offline-input/evidence/account-security-summary.json', HERE / 'source-context/account-security-summary.json'),
]:
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(original, dest)
matrix = HERE / 'source-context/hardware-matrix.tsv'
rows = list(csv.DictReader(matrix.read_text().splitlines(), delimiter='\t'))
assert len(rows) == 28 and all(r['current_status'] == 'UNTESTED' for r in rows)
assert hashlib.sha256(matrix.read_bytes()).hexdigest() == '24c30e0964dcec3326c723ad8f8b84c39104ff7a8688f33a7e997b2ef2098232'
summary = json.loads((HERE / 'test-summary.json').read_text())
assert summary['tests_run'] == 36 and not any(summary[k] for k in ['failures', 'errors', 'skipped'])
files = [HERE / name for name in ['test_lifecycle.py', 'storage-fixtures.json', 'prepare_harness.py',
    'package_evidence.py', 'lifecycle-safety-report.txt', 'test-summary.json', 'execution.log',
    'observations.json', 'retained-identities-after.txt', 'subject-hashes.json', 'environment.txt']]
for directory in ['pinned-source', 'subject', 'source-context']:
    files.extend(p for p in (HERE / directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
manifest = {str(p.relative_to(HERE)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
(HERE / 'packet-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
files.append(HERE / 'packet-manifest.json')
packet = HERE / 'cm3-lifecycle-safety-evidence.zip'
with zipfile.ZipFile(packet, 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(files):
        archive.write(path, path.relative_to(HERE))
with zipfile.ZipFile(packet) as archive:
    assert archive.testzip() is None
    for name, expected in manifest.items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == expected, name
    replay = HERE / 'packet-replay'
    if replay.exists():
        raise RuntimeError('refusing to overwrite replay directory')
    archive.extractall(replay)
with (HERE / 'packet-replay.log').open('w') as stream:
    result = subprocess.run([sys.executable, 'test_lifecycle.py'], cwd=replay,
                            stdout=stream, stderr=subprocess.STDOUT, timeout=180)
assert result.returncode == 0
replayed = json.loads((replay / 'test-summary.json').read_text())
assert replayed == summary
verification = {'zip_crc': 'PASS', 'manifest_hashes': 'PASS', 'indexed_files': len(manifest),
                'portable_replay': 'PASS', 'replay_tests': replayed, 'hardware_rows_preserved_untested': len(rows),
                'packet_sha256': hashlib.sha256(packet.read_bytes()).hexdigest()}
(HERE / 'packet-verification.json').write_text(json.dumps(verification, indent=2) + '\n')
print(json.dumps(verification, indent=2))
