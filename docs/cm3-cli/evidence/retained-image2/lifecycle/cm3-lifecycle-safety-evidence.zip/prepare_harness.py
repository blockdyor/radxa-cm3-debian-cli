import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
UPSTREAM = Path('/opt/data/kanban/workspaces/t_6c2ac45f/built-source')
texts = json.loads((HERE / 'offline-input/evidence/lifecycle-script-text.json').read_text())
root = HERE / 'subject'
index = {}
for absolute, text in texts.items():
    path = root / absolute.lstrip('/')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    index[absolute] = hashlib.sha256(path.read_bytes()).hexdigest()
assert index['/usr/lib/cm3-cli/enroll.py'] == '27851a6ba0ca772249e88797df6656ee507ec657dfd33c4f915a266e61381462'
assert index['/usr/lib/u-boot/radxa-cm3-rpi-cm4-io/setup.sh'] == 'b56117ef1982e72911a836432bbe3a5d22b82161b93eb592ef2751dd44d44a69'
for relative in ['tests/cm3-cli/test_board_support.py', 'tests/cm3-cli/test_firstboot_boundaries.py', 'tests/cm3-cli/test_boot_update_recovery.py', 'packages/cm3-cli-board-support/build.py']:
    dest = HERE / 'pinned-source' / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(UPSTREAM / relative, dest)
for absolute, relative in {
    '/usr/lib/cm3-cli/enroll.py': 'packages/cm3-cli-board-support/root/usr/lib/cm3-cli/enroll.py',
    '/usr/lib/cm3-cli/owner_config.py': 'scripts/cm3-owner-config.py',
    '/usr/lib/cm3-cli/boot-update': 'packages/cm3-cli-board-support/root/usr/lib/cm3-cli/boot-update',
}.items():
    dest = HERE / 'pinned-source' / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(root / absolute.lstrip('/'), dest)
(HERE / 'subject-hashes.json').write_text(json.dumps(index, indent=2) + '\n')
print('Installed-script hashes PASS; pinned test helpers copied')
