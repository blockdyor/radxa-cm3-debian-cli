"""Execute installed logic with fixture roots and recording command doubles only."""
import errno
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
(HERE / '.tmp').mkdir(exist_ok=True, mode=0o700)
os.environ['TMPDIR'] = str(HERE / '.tmp')
tempfile.tempdir = str(HERE / '.tmp')
sys.path.insert(0, str(HERE / 'pinned-source/tests/cm3-cli'))
import test_board_support as fixtures
from test_firstboot_boundaries import FirstbootBoundaryTests
from test_boot_update_recovery import BootUpdateTests

E = fixtures.enrollment
OBSERVATIONS = []


class IdentityTests(unittest.TestCase):
    def setUp(self):
        self.f = fixtures.EnrollmentTests()
        self.addCleanup(self.f.doCleanups)
        self.f.setUp()
        self.root = self.f.root

    def enroll(self, command=None):
        # Never invoke the module's default host command executor.
        with patch.object(E.subprocess, 'run', side_effect=self.safe_subprocess):
            E.enroll(self.root, command or self.f.command)

    @staticmethod
    def safe_subprocess(args, **kwargs):
        # Only OpenSSH with its explicit disposable prefix may reach the OS.
        assert args[:3] == ['ssh-keygen', '-A', '-f'], args
        root = Path(args[3]).resolve()
        assert root.is_relative_to(Path(os.environ['TMPDIR']).resolve())
        return REAL_RUN(args, **kwargs)

    def test_pristine_no_owner_stops_before_accounts_or_keys(self):
        (self.root / 'etc/cm3-cli/owner.json').unlink()
        with self.assertRaises(FileNotFoundError):
            self.enroll()
        self.assertEqual(self.f.calls, [])
        self.assertFalse((self.root / E.READY).exists())

    def test_existing_identity_and_repeat_enrollment_are_stable(self):
        self.enroll()
        before = {p.name: p.read_bytes() for p in (self.root / 'etc/ssh').glob('ssh_host_*')}
        state = (self.root / E.STATE).read_bytes()
        self.enroll()
        E.check(self.root)
        self.assertEqual(before, {p.name: p.read_bytes() for p in (self.root / 'etc/ssh').glob('ssh_host_*')})
        self.assertEqual(state, (self.root / E.STATE).read_bytes())
        self.assertEqual(sum(c[0].endswith('adduser') for c in self.f.calls), 1)

    def test_missing_machine_id_fails_closed_not_generated_by_enrollment(self):
        (self.root / 'etc/machine-id').unlink()
        with self.assertRaises(FileNotFoundError):
            self.enroll()
        self.assertFalse((self.root / E.READY).exists())
        self.assertFalse((self.root / 'etc/machine-id').exists())

    def test_empty_or_zero_machine_id_is_rejected(self):
        for value in ['', '0' * 32, 'not-an-id']:
            with self.subTest(value=value):
                self.f.put('etc/machine-id', value)
                with self.assertRaisesRegex(ValueError, 'machine identity'):
                    self.enroll()
                self.assertFalse((self.root / E.READY).exists())

    def test_absent_host_keys_fresh_and_distinct_across_fixture_roots(self):
        self.enroll()
        first = (self.root / 'etc/ssh/ssh_host_ed25519_key.pub').read_bytes()
        other = fixtures.EnrollmentTests()
        try:
            other.setUp()
            with patch.object(E.subprocess, 'run', side_effect=self.safe_subprocess):
                E.enroll(other.root, other.command)
            self.assertNotEqual(first, (other.root / 'etc/ssh/ssh_host_ed25519_key.pub').read_bytes())
        finally:
            other.doCleanups()

    def test_preexisting_stale_keys_and_duplicate_machine_id_are_accepted(self):
        self.enroll()
        before = {p.name: p.read_bytes() for p in (self.root / 'etc/ssh').glob('ssh_host_*')}
        # An arbitrary preexisting nonempty private key is not cryptographically validated.
        self.f.put('etc/ssh/ssh_host_ed25519_key', 'STALE-FIXTURE-NOT-A-PRIVATE-KEY', 0o600)
        self.enroll()
        E.check(self.root)
        self.assertEqual((self.root / 'etc/ssh/ssh_host_ed25519_key').read_text(), 'STALE-FIXTURE-NOT-A-PRIVATE-KEY')
        self.assertEqual((self.root / 'etc/machine-id').read_text().strip(), '1234567890abcdef1234567890abcdef')
        self.assertEqual(before['ssh_host_rsa_key'], (self.root / 'etc/ssh/ssh_host_rsa_key').read_bytes())
        OBSERVATIONS.append({'finding': 'identity-readiness-does-not-detect-stale-or-invalid-keys-or-duplicate-machine-id', 'verdict': 'demonstrated limitation'})

    def test_readonly_state_write_fails_before_accounts(self):
        with patch.object(E, 'atomic', side_effect=OSError(errno.EROFS, 'fixture read-only filesystem')):
            with self.assertRaises(OSError) as error:
                self.enroll()
        self.assertEqual(error.exception.errno, errno.EROFS)
        self.assertEqual(self.f.calls, [])
        self.assertFalse((self.root / E.READY).exists())

    def test_key_generation_failure_keeps_ssh_gate_closed_and_retry_recovers(self):
        def fail(*args):
            if args[0].endswith('ssh-keygen'):
                raise subprocess.CalledProcessError(1, 'fixture-keygen')
            self.f.command(*args)
        with self.assertRaises(subprocess.CalledProcessError):
            self.enroll(fail)
        self.assertFalse((self.root / E.READY).exists())
        self.enroll()
        E.check(self.root)

    def test_changed_owner_requires_offline_recovery_without_commands(self):
        self.enroll()
        self.f.calls.clear()
        self.f.config['username'] = 'bob'
        self.f.owner()
        with self.assertRaisesRegex(ValueError, 'offline administrator recovery'):
            self.enroll()
        self.assertEqual(self.f.calls, [])
        self.assertFalse((self.root / E.READY).exists())


REAL_RUN = subprocess.run
SETUP = HERE / 'subject/usr/lib/u-boot/radxa-cm3-rpi-cm4-io/setup.sh'
MOCKS = r'''
# No external commands can resolve: all mutators are recording functions.
export PATH=/nonexistent
export LC_ALL=C
unset BASH_ENV ENV
function dd { printf 'DD'; printf ' <%s>' "$@"; printf '\n'; return "${DD_STATUS:-0}"; }
function sync { printf 'SYNC'; printf ' <%s>' "$@"; printf '\n'; }
function rkdeveloptool { printf 'RK'; printf ' <%s>' "$@"; printf '\n'; if [[ $1 == db ]]; then return "${RK_DB_STATUS:-0}"; fi; return "${RK_STATUS:-0}"; }
function rm { printf 'RM'; printf ' <%s>' "$@"; printf '\n'; }
function sleep { :; }
function truncate { printf 'TRUNCATE\n'; }
function flash_erase { printf 'ERASE\n'; }
function flashcp { printf 'FLASH\n'; }
source "$SUBJECT"
set -euo pipefail
SCRIPT_DIR="$PAYLOAD"
case "$ACTION" in
 update_bootloader|erase_bootloader) "$ACTION" "$TARGET" ;;
 maskrom_autoupdate_bootloader) "$ACTION" ;;
 *) exit 88 ;;
esac
'''


class StorageTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.payload = self.root / 'payload'
        self.payload.mkdir()
        for name in ['idblock.img', 'u-boot.itb']:
            (self.payload / name).write_bytes(b'SYNTHETIC-PAYLOAD')
        self.devices = json.loads((HERE / 'storage-fixtures.json').read_text())
        for item in self.devices:
            (self.root / item['name']).write_bytes(b'UNRELATED-DATA-SENTINEL')

    def run_action(self, action, name, **statuses):
        self.assertEqual(hashlib.sha256(SETUP.read_bytes()).hexdigest(), 'b56117ef1982e72911a836432bbe3a5d22b82161b93eb592ef2751dd44d44a69')
        result = REAL_RUN(['/usr/bin/bash', '--noprofile', '--norc'], input=MOCKS, text=True,
                          capture_output=True, cwd=self.root, timeout=10,
                          env={'SUBJECT': str(SETUP), 'PAYLOAD': str(self.payload),
                               'ACTION': action, 'TARGET': str(self.root / name), **statuses})
        OBSERVATIONS.append({'action': action, 'target': name, 'injected_statuses': statuses,
                             'exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
        for item in self.devices:
            self.assertEqual((self.root / item['name']).read_bytes(), b'UNRELATED-DATA-SENTINEL')
        return result

    def test_explicit_targets_sd_emmc_nvme_usb_have_exact_write_offsets(self):
        for item in self.devices:
            with self.subTest(device=item):
                result = self.run_action('update_bootloader', item['name'])
                self.assertEqual(result.returncode, 0)
                writes = [line for line in result.stdout.splitlines() if line.startswith('DD')]
                self.assertEqual(len(writes), 3)
                self.assertTrue(all('of=' + str(self.root / item['name']) in w for w in writes))
                self.assertIn('<bs=4096> <seek=136>', writes[0])
                self.assertIn('<bs=512> <seek=64>', writes[1])
                self.assertIn('<bs=512> <seek=16384>', writes[2])

    def test_data_nvme_not_selected_implicitly_but_explicit_data_target_not_rejected(self):
        result = self.run_action('update_bootloader', 'mmcblk1')
        self.assertNotIn('nvme0n1', result.stdout)
        result = self.run_action('update_bootloader', 'nvme0n1')
        self.assertEqual(result.returncode, 0)
        self.assertIn('of=' + str(self.root / 'nvme0n1'), result.stdout)

    def test_partition_target_not_rejected(self):
        result = self.run_action('update_bootloader', 'mmcblk1p3')
        self.assertEqual(result.returncode, 0)
        self.assertIn('of=' + str(self.root / 'mmcblk1p3'), result.stdout)

    def test_missing_bootloader_payload_allows_partial_write_before_failure(self):
        (self.payload / 'u-boot.itb').unlink()
        result = self.run_action('update_bootloader', 'mmcblk1')
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('Missing U-Boot binary', result.stderr)
        self.assertEqual(result.stdout.count('DD '), 2)

    def test_readonly_write_error_stops_later_writes_in_strict_dispatch(self):
        result = self.run_action('update_bootloader', 'mmcblk1', DD_STATUS='30')
        self.assertEqual(result.returncode, 30)
        self.assertEqual(result.stdout.count('DD '), 1)
        self.assertNotIn('SYNC', result.stdout)

    def test_erase_only_records_explicit_target(self):
        result = self.run_action('erase_bootloader', 'mmcblk1')
        self.assertEqual(result.returncode, 0)
        self.assertIn('<seek=64> <count=16384>', result.stdout)
        self.assertNotIn('nvme0n1', result.stdout)

    def test_repeated_install_has_identical_write_intent(self):
        first = self.run_action('update_bootloader', 'mmcblk1')
        second = self.run_action('update_bootloader', 'mmcblk1')
        self.assertEqual(first.stdout, second.stdout)
        self.assertEqual(first.returncode, second.returncode)

    def test_maskrom_loader_error_is_ignored_before_write_and_reset(self):
        result = self.run_action('maskrom_autoupdate_bootloader', 'mmcblk1', RK_DB_STATUS='19')
        self.assertEqual(result.returncode, 0)
        self.assertIn('RK <db>', result.stdout)
        self.assertIn('RK <wl>', result.stdout)
        self.assertIn('RK <rd>', result.stdout)


if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__])
    # Existing exact-source fixture tests use only explicit disposable OpenSSH prefixes.
    suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(fixtures.EnrollmentTests))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    (HERE / 'observations.json').write_text(json.dumps(OBSERVATIONS, indent=2) + '\n')
    (HERE / 'test-summary.json').write_text(json.dumps({'tests_run': result.testsRun,
        'failures': len(result.failures), 'errors': len(result.errors), 'skipped': len(result.skipped),
        'python': sys.version, 'evidence': 'native userspace / mocked side effects, not ARM64 virtual boot'}, indent=2) + '\n')
    sys.exit(not result.wasSuccessful())
