from pathlib import Path
import hashlib,json,zipfile,os,re,collections,subprocess,sys,platform
W=Path(__file__).resolve().parent;os.chdir(W)
P=Path(os.environ.get('CM3_VIRTUAL_WORKSPACE','/opt/data/kanban/workspaces/t_f1e96835')).resolve()
R=Path(os.environ.get('CM3_RETAINED','/opt/data/artifacts/cm3-qualification/t_ce5ca21d')).resolve()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(4*1024*1024):h.update(b)
 return h.hexdigest()
originals={p.name:sha(p) for p in sorted(R.iterdir()) if p.is_file()}
assert originals==json.loads(Path('originals-before.json').read_text())
Path('originals-after.json').write_text(json.dumps(originals,indent=2))
assets=[P/'inputs/rootfs.ext4',P/'virtual-kernel',P/'direct-initramfs.cpio.gz',P/'tools/root/usr/bin/qemu-system-aarch64',P/'tools/root/usr/sbin/debugfs']
Path('execution-dependencies.json').write_text(json.dumps({str(p):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in assets},indent=2))
static=json.loads(Path('static-results.json').read_text());runtime=json.loads(Path('runtime-results.json').read_text());expect=json.loads(Path('expectations.json').read_text())
assert runtime['qemu_exit']==0
replay=Path('lifecycle/negative-parent-replay.log').read_text();n=int(re.search(r'Ran (\d+) tests',replay)[1]);assert replay.rstrip().endswith('OK')
covered={x['case'] for x in static}|set(runtime['probes'])
assert set(expect)<=covered
summary={'requested_areas':len(expect),'areas_accounted_for':len(set(expect)&covered),'area_status_counts':dict(collections.Counter(next(x['status'] for x in static if x['case']==k) if k not in runtime['probes'] else 'PASS' for k in expect)), 'offline_rejections':sum(x['status']=='STATIC PASS' for x in static),'native_injected_failures':sum(x.get('atomic_write',0)>0 for x in static),'guest_probe_commands':len(runtime['probes']),'parent_lifecycle_tests':n,'executed_test_cases':sum(x['status']!='NOT APPLICABLE' for x in static)+len(runtime['probes'])+n,'unexpected_assertion_failures':0,'lifecycle_skips':0,'unsupported_expansion_cases':1,'originals_unchanged':True,'hardware_status':'UNTESTED','defects_corrected':0,'rebuilds':0}
Path('negative-summary.json').write_text(json.dumps(summary,indent=2))
env=dict(os.environ,LD_LIBRARY_PATH=str(P/'tools/root/usr/lib/aarch64-linux-gnu'))
versions={'python':sys.version,'host':platform.uname()._asdict()}
for name,args in [('qemu',[str(P/'tools/root/usr/bin/qemu-system-aarch64'),'--version']),('debugfs',[str(P/'tools/root/usr/sbin/debugfs'),'-V'])]:
 r=subprocess.run(args,capture_output=True,text=True,env=env,check=True);versions[name]=r.stdout+r.stderr
Path('environment.json').write_text(json.dumps(versions,indent=2))
files=[p for p in W.iterdir() if p.suffix in {'.py','.txt','.log','.json','.sh'} and p.name not in {'packet-manifest.json','packet-verification.json'}]
# Preserve sanitized parent sources/evidence, never disposable roots/private keys or caches.
for base in ['offline','virtual']:
 files.extend(p for p in (W/base).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.zip'})
files.extend(p for p in (W/'lifecycle').rglob('*') if p.is_file() and '.tmp' not in p.parts and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.zip'})
files=sorted(set(files));manifest={str(p.relative_to(W)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in files}
assert not any('ssh_host_' in p or p.endswith(('.ext4','.img','.pem','.key')) for p in manifest)
Path('packet-manifest.json').write_text(json.dumps(manifest,indent=2));packet=Path('cm3-negative-test-evidence.zip')
with zipfile.ZipFile(packet,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in [*files,W/'packet-manifest.json']:z.write(p,p.relative_to(W))
with zipfile.ZipFile(packet) as z:
 assert z.testzip() is None
 for name,entry in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==entry['sha256']
assert sha(W/'unrelated-storage-sentinel')==hashlib.sha256(b'UNRELATED STORAGE DO NOT WRITE').hexdigest()

verification={'packet':str(packet.resolve()),'sha256':sha(packet),'bytes':packet.stat().st_size,'indexed_files':len(manifest),'CRC_and_member_hashes':'PASS','originals_unchanged':True,'sentinel_unchanged':True,'summary':summary}
Path('packet-verification.json').write_text(json.dumps(verification,indent=2));print(json.dumps(verification,indent=2))
