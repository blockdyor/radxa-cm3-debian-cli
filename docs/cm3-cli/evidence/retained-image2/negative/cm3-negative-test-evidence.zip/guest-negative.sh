#!/bin/bash
# Direct-init retained userspace; no host disks or network attached.
set -u
exec >/dev/ttyAMA0 2>&1
run() { echo "NEG_BEGIN $1"; label=$1; shift; "$@"; rc=$?; echo "NEG_END $label $rc"; }
echo CM3_NEGATIVE_BEGIN
mkdir -p /run/negative/lists/partial /run/negative/cache/archives/partial
printf 'deb [ deliberately-broken\n' >/run/negative/broken.list
run broken_apt_source bash -c 'apt-get -o Dir::Etc::sourcelist=/run/negative/broken.list -o Dir::Etc::sourceparts=- -o Dir::State::lists=/run/negative/lists -o Dir::Cache=/run/negative/cache update && echo UNSAFE_APT_CONTINUATION'
run duplicate_machine_id bash -c '
set -e
for r in a b; do
 mkdir -p /run/negative/$r/etc
 printf "1234567890abcdef1234567890abcdef\n" >/run/negative/$r/etc/machine-id
 systemd-machine-id-setup --root=/run/negative/$r
 grep -qx 1234567890abcdef1234567890abcdef /run/negative/$r/etc/machine-id
done
cmp /run/negative/a/etc/machine-id /run/negative/b/etc/machine-id
echo DUPLICATE_ID_PRESERVED_NOT_DETECTED
'
run preexisting_ssh_host_keys bash -c '
set -e
for r in a b; do mkdir -p /run/negative/$r/etc/ssh; done
ssh-keygen -A -f /run/negative/a
cp /run/negative/a/etc/ssh/ssh_host_* /run/negative/b/etc/ssh/
sha256sum /run/negative/b/etc/ssh/ssh_host_* > /run/negative/key-before
ssh-keygen -A -f /run/negative/b
sha256sum -c /run/negative/key-before
cmp /run/negative/a/etc/ssh/ssh_host_ed25519_key.pub /run/negative/b/etc/ssh/ssh_host_ed25519_key.pub
echo CLONED_KEYS_PRESERVED_NOT_DETECTED
rm /run/negative/b/etc/ssh/ssh_host_*
ssh-keygen -A -f /run/negative/b
if cmp -s /run/negative/a/etc/ssh/ssh_host_ed25519_key.pub /run/negative/b/etc/ssh/ssh_host_ed25519_key.pub; then exit 91; fi
echo EXPLICIT_KEY_REMOVAL_REGENERATES_DISTINCT_KEY
'
mkdir -p /run/negative/full
mount -t tmpfs -o size=64k,mode=0700 tmpfs /run/negative/full
run insufficient_free_space bash -c 'dd if=/dev/zero of=/run/negative/full/payload bs=4096 count=32 status=none && echo UNSAFE_SPACE_CONTINUATION'
run space_recovery bash -c 'rm /run/negative/full/payload && echo retained-guest-write-resumed >/run/negative/full/recovered && test -s /run/negative/full/recovered'
echo CM3_NEGATIVE_COMPLETE
sync
/sbin/poweroff -ff
