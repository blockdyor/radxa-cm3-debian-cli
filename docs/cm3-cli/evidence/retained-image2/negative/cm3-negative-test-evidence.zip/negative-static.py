from pathlib import Path
import os,sys,json,hashlib,subprocess,shutil,importlib.util,errno
from unittest.mock import patch
W=Path(__file__).resolve().parent;os.chdir(W)
P=Path(os.environ.get('CM3_VIRTUAL_WORKSPACE','/opt/data/kanban/workspaces/t_f1e96835')).resolve()
T=P/'tools/root';env=dict(os.environ,LD_LIBRARY_PATH=str(T/'usr/lib/aarch64-linux-gnu'))
R=Path(os.environ.get('CM3_RETAINED','/opt/data/artifacts/cm3-qualification/t_ce5ca21d')).resolve()
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(4*1024*1024):h.update(b)
 return h.hexdigest()
def identities():return {p.name:digest(p) for p in sorted(R.iterdir()) if p.is_file()}
json.loads(Path('expectations.json').read_text())
before=identities();Path('originals-before.json').write_text(json.dumps(before,indent=2))
assert before['cm3-trixie-arm64-cli.img']=='b0d1f56240fafc49cc32ceab0f041d4bb6f529604635684135ccc6ad26ebbff8'
sentinel=Path('unrelated-storage-sentinel');sentinel.write_bytes(b'UNRELATED STORAGE DO NOT WRITE');sentinel_before=digest(sentinel)
results=[];commands=[]
def load(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
contract=load('contract','offline/built-source/scripts/cm3-image-contract.py')
publish=load('publish','offline/built-source/scripts/cm3-publish-image.py')
def reject(name,mutation,action,kind,message):
 try:action()
 except kind as e:
  assert message in str(e),(name,str(e));results.append(dict(case=name,mutation=mutation,status='STATIC PASS',detector='validation harness/pinned tooling only',exception=type(e).__name__,diagnostic=str(e),unsafe_continuation=False))
 else:raise AssertionError(name+' accepted')
source=Path('offline/records/sources/source-lock.json').read_bytes();assert isinstance(json.loads(source),dict);Path('corrupt-manifest.json').write_bytes(source[:40])
reject('corrupt_manifest','source-lock.json bytes[:40]',lambda:json.loads(Path('corrupt-manifest.json').read_text()),json.JSONDecodeError,'')
d=(W/'delivery-fixture');d.mkdir(exist_ok=True);(d/'source-lock.json').write_bytes(source);(d/'delivery-inputs.json').write_text('{}')
reject('wrong_checksum','source-lock.json digest replaced by 64 zeroes',lambda:publish.checked_materials(d,{'files':{'source-lock.json':'0'*64}}),ValueError,'hash mismatch')
try:publish.checked_materials(d,{'files':{'source-lock.json':digest(d/'source-lock.json')}})
except ValueError as e:assert str(e)=='corresponding source/notices incomplete'
else:raise AssertionError('deliberately minimal fixture unexpectedly complete')
v=json.loads(Path('offline/records/verification.json').read_text());parts=v['layout']['partitions'];contract.layout(parts,v['image_bytes'],512,'gpt')
reject('missing_partition','retained layout partitions[:2]',lambda:contract.layout(parts[:2],v['image_bytes'],512,'gpt'),ValueError,'three-partition')
boot=json.loads(Path('offline/evidence/boot-contract.json').read_text());ids=[p['uuid'] for p in json.loads(Path('offline/evidence/filesystem-identities.json').read_text())]
contract.boot(boot['/boot/extlinux/extlinux.conf'],boot['/etc/kernel/cmdline'],boot['/etc/fstab'],ids)
root=Path('negative-root.ext4');shutil.copyfile(P/'inputs/rootfs.ext4',root)
assert digest(root)==json.loads(Path('virtual/inputs/partitions.json').read_text())[2]['copy_sha256']
def dbg(command,write=False):
 args=[str(T/'usr/sbin/debugfs'),*(['-w'] if write else []),'-R',command,str(root)]
 r=subprocess.run(args,env=env,capture_output=True,text=True,timeout=30);commands.append(dict(argv=args,exit=r.returncode,stdout=r.stdout,stderr=r.stderr));assert r.returncode==0
 return r.stdout
fstab=dbg('cat /etc/fstab');assert fstab==boot['/etc/fstab']
Path('wrong-fstab').write_text(fstab.replace(ids[2],'00000000-0000-0000-0000-000000000000'))
dbg('rm /etc/fstab',True);dbg('write wrong-fstab /etc/fstab',True)
reject('incorrect_fstab_uuid','debugfs rm /etc/fstab; write wrong-fstab /etc/fstab',lambda:contract.boot(boot['/boot/extlinux/extlinux.conf'],boot['/etc/kernel/cmdline'],dbg('cat /etc/fstab'),ids),ValueError,'UUIDs disagree')
release=json.loads(Path('offline/evidence/modules-summary.json').read_text())['release'];module='/usr/lib/modules/'+release+'/kernel/arch/arm64/crypto/chacha-neon.ko.xz'
for case,p in [('missing_dtb',v['boot']['paths']['fdt'][0]),('missing_kernel_module',module)]:
 assert 'Type: regular' in dbg('stat '+p)
 if case=='missing_kernel_module':assert p.split(release+'/',1)[1] in dbg('cat /usr/lib/modules/'+release+'/modules.dep')
 dbg('rm '+p,True)
 def check_file(p=p):
  if 'Type: regular' not in dbg('stat '+p):raise ValueError('required referenced file missing: '+p)
 reject(case,'debugfs -w -R rm '+p,check_file,ValueError,'required referenced file missing')
sys.path.insert(0,str(W/'lifecycle'));import test_lifecycle as life
assert digest(Path(life.E.__file__))==v['board_policy_sha256']['/usr/lib/cm3-cli/enroll.py']
for failure in range(1,6):
 f=life.fixtures.EnrollmentTests();f.setUp();atomic=life.E.atomic;counter=[0]
 def full(*args,**kwargs):
  counter[0]+=1
  if counter[0]==failure:raise OSError(errno.ENOSPC,'injected no space left on device')
  return atomic(*args,**kwargs)
 try:
  with patch.object(life.E,'atomic',side_effect=full),patch.object(life.E.subprocess,'run',side_effect=life.IdentityTests.safe_subprocess):
   try:life.E.enroll(f.root,f.command)
   except OSError as e:assert e.errno==28
   else:raise AssertionError('ENOSPC not reached')
  assert not (f.root/life.E.READY).exists()
  results.append(dict(case='insufficient_free_space',atomic_write=failure,status='PASS',detector='native installed Python with injected errno28 and account doubles; not virtual boot',exception='OSError errno28',account_command_count=len(f.calls),readiness=False))
 finally:f.doCleanups()
results.append(dict(case='filesystem_expansion_failure',status='NOT APPLICABLE',diagnostic='No retained project expansion entrypoint; no fake implementation tested. Physical requirement UNTESTED.',detector='parent offline lifecycle inventory/source review'))
assert digest(sentinel)==sentinel_before
after=identities();assert before==after
Path('originals-after-static.json').write_text(json.dumps(after,indent=2));Path('static-results.json').write_text(json.dumps(results,indent=2));Path('static-commands.json').write_text(json.dumps(commands,indent=2));print(json.dumps(results,indent=2))
