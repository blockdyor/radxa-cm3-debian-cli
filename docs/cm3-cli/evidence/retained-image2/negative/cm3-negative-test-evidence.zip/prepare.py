from pathlib import Path
import zipfile
for name, task, packet in [('lifecycle','t_23036e0d','cm3-lifecycle-safety-evidence.zip'),('virtual','t_f1e96835','cm3-virtual-execution-evidence.zip'),('offline','t_6c2ac45f','cm3-offline-validation-evidence.zip')]:
    p=Path('/opt/data/kanban/attachments')/task/packet
    with zipfile.ZipFile(p) as z:
        assert z.testzip() is None
        assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in z.namelist())
        z.extractall(name)
        print(name, z.namelist()[:50])
