from pathlib import Path
import os,shutil,json,subprocess,hashlib,re
W=Path(__file__).resolve().parent;os.chdir(W)
P=Path(os.environ.get('CM3_VIRTUAL_WORKSPACE','/opt/data/kanban/workspaces/t_f1e96835')).resolve();T=P/'tools/root'
env=dict(os.environ,LD_LIBRARY_PATH=str(T/'usr/lib/aarch64-linux-gnu'))
# Reuse verified alternate-kernel/direct-init setup, never the parent's writable disk.
root=W/'runtime-negative.ext4';shutil.copyfile(P/'inputs/rootfs.ext4',root)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(4*1024*1024):h.update(b)
 return h.hexdigest()
assert sha(root)==json.loads((W/'virtual/inputs/partitions.json').read_text())[2]['copy_sha256']
commands=['write '+str(W/'guest-negative.sh')+' /usr/local/sbin/cm3-direct-probes']
Path('runtime-mutations.txt').write_text('\n'.join(commands)+'\n')
with open('runtime-modification.log','w') as log:
 subprocess.run([str(T/'usr/sbin/debugfs'),'-w','-f',str(W/'runtime-mutations.txt'),str(root)],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
args=[str(T/'usr/bin/qemu-system-aarch64'),'-M','virt','-cpu','cortex-a53','-accel','tcg,thread=single','-m','512','-smp','1','-nographic','-monitor','none','-kernel',str(P/'virtual-kernel'),'-initrd',str(P/'direct-initramfs.cpio.gz'),'-append','console=ttyAMA0','-drive','file='+str(root)+',format=raw,if=none,id=root','-device','virtio-blk-device,drive=root','-nic','none']
Path('runtime-command.json').write_text(json.dumps(args,indent=2))
with open('runtime-console.log','w') as log:
 try:code=subprocess.run(args,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,timeout=600).returncode
 except subprocess.TimeoutExpired:code=124
Path('runtime-exit.txt').write_text(str(code));text=Path('runtime-console.log').read_text(errors='replace')
rows={name:int(status) for name,status in re.findall(r'NEG_END (\w+) (\d+)',text)}
Path('runtime-results.json').write_text(json.dumps({'qemu_exit':code,'probes':rows},indent=2));print(code,rows)
assert code==0 and 'CM3_NEGATIVE_COMPLETE' in text
assert rows=={'broken_apt_source':100,'duplicate_machine_id':0,'preexisting_ssh_host_keys':0,'insufficient_free_space':1,'space_recovery':0},rows
assert 'UNSAFE_APT_CONTINUATION' not in text and 'UNSAFE_SPACE_CONTINUATION' not in text
assert 'Malformed' in text and 'No space left on device' in text
assert all(s in text for s in ['DUPLICATE_ID_PRESERVED_NOT_DETECTED','CLONED_KEYS_PRESERVED_NOT_DETECTED','EXPLICIT_KEY_REMOVAL_REGENERATES_DISTINCT_KEY'])
print('ALL RUNTIME EXPECTATIONS MATCH')
