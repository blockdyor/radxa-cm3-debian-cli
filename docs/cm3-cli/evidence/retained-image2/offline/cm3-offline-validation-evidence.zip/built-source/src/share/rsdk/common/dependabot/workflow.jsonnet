function() std.manifestYamlDoc(
    {
        name: "Dependabot auto-merge",
        on: {
            pull_request: {},
        },
        permissions: {
            contents: "write",
            "pull-requests": "write",
        },
        jobs: {
            dependabot: {
                "runs-on": "ubuntu-latest",
                "timeout-minutes": 10,
                "if": "github.actor == 'dependabot[bot]'",
                steps: [
                    {
                        name: "Dependabot metadata",
                        id: "metadata",
                        uses: "dependabot/fetch-metadata@v3",
                        with: {
                            "github-token": "${{ secrets.GITHUB_TOKEN }}",
                        },
                    },
                    {
                        name: "Approve a PR",
                        run: |||
                            gh pr review --approve "$PR_URL"
                        |||,
                        env: {
                            PR_URL: "${{github.event.pull_request.html_url}}",
                            GH_TOKEN: "${{secrets.GITHUB_TOKEN}}",
                        },
                    },
                    {
                        name: "Approve a PR with private token",
                        run: |||
                            gh pr review --approve "$PR_URL"
                        |||,
                        env: {
                            PR_URL: "${{github.event.pull_request.html_url}}",
                            GH_TOKEN: "${{secrets.CODE_WRITE_TOKEN}}",
                        },
                        "continue-on-error": true,
                    },
                    {
                        name: "Enable auto-merge for Dependabot PRs",
                        run: |||
                            gh pr merge --auto --merge "$PR_URL"
                        |||,
                        env: {
                            PR_URL: "${{github.event.pull_request.html_url}}",
                            // Need to use custom token to trigger merge_group actions
                            // https://github.com/orgs/community/discussions/70310
                            GH_TOKEN: "${{secrets.GITHUB_TOKEN}}",
                        },
                    },
                ],
            },
        },
    },
    quote_keys=false,
)
