function(
    target,
    pkg_org,
    git_rev,
) std.manifestYamlDoc(
    {
        name: "Publish packages",
        on: {
            workflow_dispatch: {},
            merge_group: {},
            push: {
                branches: [
                    "main",
                    "gh-readonly-queue/main/*",
                ],
                paths: [
                    "pkgs.json",
                    "pkgs.lock",
                    ".github/workflows/build.yaml",
                ],
            },
            pull_request: {
                paths: [
                    "pkgs.json",
                    "pkgs.lock",
                    ".github/workflows/build.yaml",
                ]
            },
        },
        permissions: {},
        concurrency: {
            group: "${{ github.workflow }}-${{ github.ref }}",
            "cancel-in-progress": true,
        },
        jobs: {
            build: {
                "runs-on": "ubuntu-latest",
                "timeout-minutes": 30,
                permissions: {
                    pages: "write",             // for pages
                    "id-token": "write",        // for pages
                    contents: "write",          // for release
                },
                steps: [
                    {
                        name: "Secret tests",
                        uses: "actions/github-script@v9",
                        with: {
                            script: |||
                                if (${{ secrets.RADXA_APT_KEY_2024 == '' }} ||
                                    ${{ secrets.GPG_KEY == '' }} ||
                                    ${{ secrets.RADXA_APT_KEY_2026 == '' }}) {
                                    core.setFailed('Required secrets are unset!');
                                }
                            |||,
                        },
                    },
                    {
                        name: "Checkout rsdk",
                        uses: "actions/checkout@v7",
                        with: {
                            repository: "RadxaOS-SDK/rsdk",
                            ref: "%(git_rev)s" % {git_rev: git_rev},
                        },
                    },
                    {
                        name: "Checkout current repo",
                        uses: "actions/checkout@v7",
                        with: {
                            path: ".infra-repo",
                        },
                    },
                    {
                        name: "Build apt archive",
                        id: "build",
                        shell: "bash",
                        env: {
                            GH_TOKEN: "${{ secrets.GITHUB_TOKEN }}",
                        },
                        run: |||
                            sudo apt-get update
                            sudo apt-get install -y aptly pandoc

                            # Workaround https://github.com/aptly-dev/aptly/issues/1297
                            git clone -b 1297-hack https://github.com/RadxaOS-SDK/aptly.git /tmp/aptly
                            export PATH="$HOME/go/bin:$PATH"
                            pushd /tmp/aptly
                            make release
                            popd
                            APTLY_PATH=/tmp/aptly/xc-out/*/linux_amd64
                            export PATH="$APTLY_PATH:$PATH"

                            cat << EOF | gpg --import
                            ${{ secrets.RADXA_APT_KEY_2024 }}
                            EOF
                            cat << EOF | gpg --import
                            ${{ secrets.GPG_KEY }}
                            EOF
                            cat << EOF | gpg --import
                            ${{ secrets.RADXA_APT_KEY_2026 }}
                            EOF

                            suites=(
                                "%(target)s"
                                "amlogic-%(target)s"
                                "rockchip-%(target)s"
                            )

                            logging=()
                            if [[ "$ACTIONS_STEP_DEBUG" == "true" ]]; then
                                logging+=(--verbose)
                            fi

                            pushd .infra-repo

                            ../src/bin/rsdk infra-pkg-download "${logging[@]}" "${suites[@]}"
                            ../src/bin/rsdk infra-repo-sync "${suites[@]}"
                            export RSDK_REPO_ORIGIN="$(../src/bin/rsdk config infra.repository.origin)"

                            pushd "$HOME/.aptly/public/$RSDK_REPO_ORIGIN/"
                                cp "$OLDPWD/pkgs.json" "$OLDPWD/install.sh" ./
                                pandoc --from gfm --to html --standalone "$OLDPWD/README.md" --output index.html
                                find . > files.list
                                echo "pages=$(realpath .)" | tee -a $GITHUB_OUTPUT
                            popd

                            popd
                        ||| % {target: target},
                    },
                    {
                        name: "Setup GitHub Pages",
                        uses: "actions/configure-pages@v6",
                    },
                    {
                        name: "Upload artifact",
                        uses: "actions/upload-pages-artifact@v5",
                        with: {
                            path: "${{ steps.build.outputs.pages }}"
                        },
                    },
                    {
                        name: "Deploy to GitHub Pages",
                        id: "deploy",
                        uses: "actions/deploy-pages@v5",
                        "if": "github.event_name != 'pull_request'",
                    },
                    {
                        name: "Download Pages artifact",
                        uses: "actions/download-artifact@v8",
                        with: {
                            name: "github-pages",
                        },
                    },
                    {
                        name: "Release Pages artifact",
                        "if": "steps.deploy.outcome == 'success'",
                        uses: "softprops/action-gh-release@v3",
                        with: {
                            tag_name: "github-pages",
                            body: "Rolling Pages artifact",
                            files: "artifact.tar",
                            draft: false,
                            prerelease: false,
                            token: "${{ secrets.GITHUB_TOKEN }}",
                        },
                    },
                ],
            },
        },
    },
    quote_keys=false,
)
