"""Check collected evidence and create a small, self-contained task packet."""
from pathlib import Path
import json,hashlib,zipfile,datetime,subprocess
W=Path(__file__).resolve().parent
D=W/'evidence'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(4*1024*1024):h.update(b)
 return h.hexdigest()
artifact=json.loads((W/'artifact-current.json').read_text());run=json.loads((W/'run-current.json').read_text());pr=json.loads((W/'pr-current.json').read_text())
assert artifact['id']==13044838581 and not artifact['expired'] and artifact['digest']=='sha256:cac0f8575b91529e4809d86a99fb460b2279acc19fd8eea56469dca51d959fad'
assert run['id']==41199013085 and run['conclusion']=='success' and run['head_sha']==artifact['workflow_run']['head_sha']=='2b41b830cae9efc313f3d39d85be265b6e3eae25'
identities=json.loads((W/'identities-before.json').read_text())
for name,info in identities.items():assert sha(Path(info['path']))==info['sha256']
summary=json.loads((D/'summary.json').read_text());assert summary['hardware_rows_untested']==28
scripts=json.loads((D/'lifecycle-script-text.json').read_text());units=json.loads((D/'systemd-unit-inventory.json').read_text())
lines=['LIFECYCLE HANDOFF — ACTUAL INSTALLED TEXT, NOT EXECUTED','No command in this inventory is permission to operate host storage.','']
for path in sorted(scripts):
 lines += [path, '  SHA256 '+hashlib.sha256(scripts[path].encode()).hexdigest()]
lines += ['', 'U-Boot setup.sh (full actual installed text; dangerous if executed against a physical disk):',scripts['/usr/lib/u-boot/radxa-cm3-rpi-cm4-io/setup.sh'], '', 'Symlinks/masks/aliases under /etc/systemd/system:']
for p,m in sorted(units['symlinks'].items()):lines.append(p+' -> '+str(m['link']))
(W/'lifecycle-handoff.txt').write_text('\n'.join(lines)+'\n')
# Minimal supplemental read-only inspection; never persist credentials or private keys.
import os
os.environ['LD_LIBRARY_PATH']=str(W/'tools/root/usr/lib/aarch64-linux-gnu')
def dbg(command):
 r=subprocess.run([str(W/'tools/root/usr/sbin/debugfs'),'-R',command,str(W/'rootfs.ext4')],capture_output=True,check=True)
 return r.stdout.decode(errors='replace')
extra={p:dbg('ls -p '+p) for p in ['/','/etc','/usr','/var/lib/dpkg','/etc/apt','/etc/apt/apt.conf.d','/etc/apt/trusted.gpg.d','/usr/share/keyrings']}
extra['/usr/lib/os-release']=dbg('cat /usr/lib/os-release');assert 'VERSION_CODENAME=trixie' in extra['/usr/lib/os-release'].splitlines()
extra['/usr/bin/bash ELF']=None
r=subprocess.run([str(W/'tools/root/usr/sbin/debugfs'),'-R','cat /usr/bin/bash',str(W/'rootfs.ext4')],capture_output=True,check=True)
import struct
assert r.stdout[:4]==b'\x7fELF' and struct.unpack_from('<H',r.stdout,18)[0]==183
extra['/usr/bin/bash ELF']='AArch64 (EM183)'
(D/'root-and-apt-inventory.json').write_text(json.dumps(extra,indent=2))
# Store only ordinary public APT configuration, never auth.conf or credential material.
import re
aptconf={}
for line in extra['/etc/apt/apt.conf.d'].splitlines():
 row=line.split('/')
 if len(row)>=7 and row[2].startswith('10'):
  name=row[5]
  if re.fullmatch('[A-Za-z0-9_.-]+',name):
   body=dbg('cat /etc/apt/apt.conf.d/'+name)
   if re.search(r'password|passwd|token|secret|://[^/\s]+@',body,re.I):aptconf[name]='REDACTED: potential sensitive configuration; security worker must inspect locally'
   else:aptconf[name]=body
(D/'apt-config.json').write_text(json.dumps(aptconf,indent=2))
meta={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'artifact':{'id':artifact['id'],'digest':artifact['digest'],'expiry':artifact['expires_at'],'expired':artifact['expired']},'built_commit':run['head_sha'],'run_url':run['html_url'],'run_conclusion':run['conclusion'],'pr':{'url':pr['html_url'],'state':pr['state'],'draft':pr['draft'],'current_head':pr['head']['sha']},'post_inspection_retained_hashes_unchanged':True,'summary':summary,'security_limit':'No private-key/secret exhaustive scan or fresh signature validation; assigned to downstream security task.'}
(D/'verified-handoff.json').write_text(json.dumps(meta,indent=2))
# Evidence/provenance and original source/test fixtures only. No disk copies, keys or tools are bundled.
selected=[]
for directory in ['evidence','records','prior','built-source']:
 selected.extend(p for p in (W/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
for name in ['prepare.py','offline-inspect.py','finalize.py','offline-validation-report.txt','lifecycle-handoff.txt','identities-before.json','identities-after.txt','partition-table.json','tool-downloads.json','artifact-current.json','run-current.json','pr-current.json','offline-execution.log']:
 selected.append(W/name)
assert all(p.is_file() for p in selected)
manifest={str(p.relative_to(W)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in selected}
(W/'packet-manifest.json').write_text(json.dumps(manifest,indent=2))
packet=W/'cm3-offline-validation-evidence.zip'
with zipfile.ZipFile(packet,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for p in selected+[W/'packet-manifest.json']:z.write(p,p.relative_to(W))
with zipfile.ZipFile(packet) as z:
 assert z.testzip() is None
 for name,info in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==info['sha256']
assert packet.stat().st_size<25*1024*1024
print(json.dumps({'handoff':meta,'packet_path':str(packet),'packet_bytes':packet.stat().st_size,'packet_sha256':sha(packet),'indexed_files':len(manifest),'zip_crc_and_indexed_hashes':'PASS'},indent=2))
