"""File-only inspection of verified partition copies. Never execute target code."""
from pathlib import Path
import subprocess,os,json,re,posixpath,hashlib,struct,uuid,email.parser,importlib.util,gzip,zlib,sys,platform,lzma
W=Path(__file__).resolve().parent;os.chdir(W)
os.environ['LD_LIBRARY_PATH']=str(W/'tools/root/usr/lib/aarch64-linux-gnu')
OUT=Path('evidence');OUT.mkdir(exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def save(name,data):
 (OUT/name).write_text(json.dumps(data,indent=2) if not isinstance(data,str) else data)
commands=[]
def run(args):
 r=subprocess.run(args,capture_output=True);commands.append({'argv':args,'exit':r.returncode})
 return r
DBG='tools/root/usr/sbin/debugfs'
def dbg(command):
 r=run([DBG,'-R',command,'rootfs.ext4']);assert r.returncode==0
 return r.stdout.decode(errors='replace'),r.stderr.decode(errors='replace')
cache={}
def stat(path):
 if path not in cache:
  s,e=dbg('stat '+json.dumps(path));m=re.search(r'Type: (\w+)\s+Mode:\s+(\d+)',s);o=re.search(r'User:\s+(\d+)\s+Group:\s+(\d+)',s)
  link=re.search(r'Fast link dest: "(.*)"',s)
  cache[path]=None if m is None else {'type':m[1],'mode':m[2],'uid':int(o[1]),'gid':int(o[2]),'link':link[1] if link else None}
 return cache[path]
def resolve(path,depth=0):
 assert depth<32
 current=''
 for i,part in enumerate(posixpath.normpath(path).strip('/').split('/')):
  current+='/'+part;m=stat(current)
  if m and m['type']=='symlink':
   assert m['link'] is not None
   return resolve(posixpath.join(posixpath.dirname(current),m['link'],*posixpath.normpath(path).strip('/').split('/')[i+1:]),depth+1)
 return current
def read(path):
 path=resolve(path);assert stat(path) and stat(path)['type']=='regular',path
 r=run([DBG,'-R','cat '+json.dumps(path),'rootfs.ext4']);assert r.returncode==0
 return r.stdout
def text(path):return read(path).decode()
def ls(path):
 s,e=dbg('ls -p '+json.dumps(path));rows=[]
 for line in s.splitlines():
  p=line.split('/')
  if len(p)>=7 and p[1].isdigit() and int(p[1]) and p[5] not in ['.','..']:
   rows.append({'path':posixpath.join(path,p[5]),'mode':p[2],'uid':int(p[3]),'gid':int(p[4]),'size':p[6]})
 return rows
def walk(path):
 result=[]
 for row in ls(path):
  result.append(row)
  if row['mode'].startswith('04'):result.extend(walk(row['path']))
 return result
# Small parser self-check, including malformed input, before reading real initramfs.
def cpio(data,start=0):
 result=[];p=start
 while True:
  assert data[p:p+6] in [b'070701',b'070702'],('bad cpio',p,data[p:p+8])
  fields=[int(data[p+6+i*8:p+14+i*8],16) for i in range(13)]
  mode,size,nlen=fields[1],fields[6],fields[11];assert 0<nlen<4096
  name=data[p+110:p+110+nlen-1].decode();assert data[p+110+nlen-1:p+110+nlen]==b'\0'
  p=(p+110+nlen+3)&~3;assert p+size<=len(data)
  payload=data[p:p+size];p=(p+size+3)&~3
  if name=='TRAILER!!!':return result,p
  assert not name.startswith('/') and '..' not in Path(name).parts
  result.append({'path':name,'mode':oct(mode),'bytes':size,'sha256':sha(payload)})
def fixture(name,payload=b''):
 values=[1,0o100644,0,0,1,0,len(payload),0,0,0,0,len(name)+1,0]
 header=b'070701'+b''.join(f'{n:08x}'.encode() for n in values)+name.encode()+b'\0'
 header+=bytes((-len(header))%4);header+=payload;return header+bytes((-len(header))%4)
sample=fixture('init',b'abc')+fixture('TRAILER!!!');assert cpio(sample)[0][0]['sha256']==sha(b'abc')
try:cpio(b'bad')
except AssertionError:pass
else:raise AssertionError('malformed parser test failed')
versions={'python':sys.version,'machine':platform.machine()}
for tool,args in [('debugfs',['-V']),('e2fsck',['-V']),('fsck.fat',['--help'])]:
 r=run(['tools/root/usr/sbin/'+tool,*args]);versions[tool]=(r.stdout+r.stderr).decode(errors='replace').splitlines()[:3]
save('tool-versions.json',versions)
for tool,args,target in [('e2fsck',['-fn'],'rootfs.ext4'),('fsck.fat',['-n','-v'],'fat1.img'),('fsck.fat',['-n','-v'],'fat2.img')]:
 before=sha(Path(target).read_bytes());r=run(['tools/root/usr/sbin/'+tool,*args,target]);save(target+'-fsck.txt',(r.stdout+r.stderr).decode());assert r.returncode==0,(target,r.returncode)
 assert sha(Path(target).read_bytes())==before
parts=json.loads(Path('partition-table.json').read_text());uuids=[]
for part in parts:
 target='rootfs.ext4' if part['number']==3 else f"fat{part['number']}.img"
 with open(target,'rb') as f:b=f.read(2048)
 if part['number']<3:
  assert b[510:512]==b'\x55\xaa' and b[54:62]==b'FAT16   '
  serial=f'{struct.unpack_from("<I",b,39)[0]:08X}';u=serial[:4]+'-'+serial[4:];kind='FAT16'
 else:assert b[1080:1082]==b'\x53\xef';u=str(uuid.UUID(bytes=b[1128:1144]));kind='ext4'
 uuids.append(u);part.update(uuid=u,filesystem=kind)
spec=importlib.util.spec_from_file_location('contract',Path('built-source/scripts/cm3-image-contract.py'));contract=importlib.util.module_from_spec(spec);spec.loader.exec_module(contract)
boot={p:text(p) for p in ['/boot/extlinux/extlinux.conf','/etc/kernel/cmdline','/etc/fstab','/etc/u-boot-menu/conf.d/99-cm3-cli.conf','/etc/initramfs-tools/conf.d/cm3-cli']}
boot['result']=contract.boot(boot['/boot/extlinux/extlinux.conf'],boot['/etc/kernel/cmdline'],boot['/etc/fstab'],uuids)
save('boot-contract.json',boot);save('filesystem-identities.json',parts)
verification=json.loads(Path('records/verification.json').read_text())
for path,expected in verification['boot_file_sha256'].items():assert sha(read(path))==expected,path
config=text('/boot/config-6.1.84-18+cm3cli1-rk2410-nocsf')
required=['CONFIG_ARM64=y','CONFIG_BLK_DEV_INITRD=y','CONFIG_SECURITY_APPARMOR=y','CONFIG_NAMESPACES=y','CONFIG_CGROUPS=y','CONFIG_SECCOMP=y','CONFIG_EXT4_FS=y']
assert all(line in config.splitlines() for line in required)
save('kernel-config-summary.json',{'sha256':sha(config.encode()),'required_lines':required,'active_runtime':'UNTESTED'})
kernel=boot['result']['paths']['linux'][0];assert read(kernel)[56:60]==b'ARM\x64'
dtb=read(boot['result']['paths']['fdt'][0]);assert dtb[:4]==b'\xd0\x0d\xfe\xed' and b'radxa,cm3-rpi-cm4-io\0' in dtb and b'rockchip,rk3566\0' in dtb
save('boot-contents.json',walk('/boot'))
# Initramfs listing only, no file extraction or init execution; cap inflation at256MiB.
initrd=read(boot['result']['paths']['initrd'][0]);p=0;members=[];streams=[]
while p<len(initrd):
 while p<len(initrd) and initrd[p]==0:p+=1
 if p==len(initrd):break
 if initrd[p:p+6] in [b'070701',b'070702']:
  rows,p=cpio(initrd,p);members+=rows;streams.append('uncompressed cpio')
 elif initrd[p:p+2]==b'\x1f\x8b':
  dec=zlib.decompressobj(16+zlib.MAX_WBITS);data=dec.decompress(initrd[p:],256*1024*1024+1);assert len(data)<=256*1024*1024 and dec.eof
  p=len(initrd)-len(dec.unused_data);rows,end=cpio(data);assert not data[end:].strip(b'\0');members+=rows;streams.append('gzip cpio')
 else:raise AssertionError(('unknown initramfs stream',p,initrd[p:p+8]))
assert any(r['path']=='init' for r in members)
save('initramfs-members.json',{'streams':streams,'count':len(members),'members':members,'execution':'UNTESTED'})
release=kernel.removeprefix('/boot/vmlinuz-');modroot='/usr/lib/modules/'+release
module_inventory=walk(modroot);save('module-inventory.json',module_inventory)
regular={r['path'] for r in module_inventory if r['mode'].startswith('10')}
deps=text(modroot+'/modules.dep');references=set()
for line in deps.splitlines():
 name,requires=line.split(':',1);references.update([name,*requires.split()])
assert all(modroot+'/'+n in regular for n in references)
module_paths=sorted(p for p in regular if p.endswith(('.ko','.ko.xz')));assert module_paths
for path in [module_paths[0],module_paths[-1]]:
 b=read(path)
 if path.endswith('.xz'):b=lzma.decompress(b)
 assert b[:4]==b'\x7fELF' and struct.unpack_from('<H',b,18)[0]==183 and ('vermagic='+release).encode() in b,path
save('modules-summary.json',{'release':release,'dependency_paths_checked':len(references),'ko_files':len(module_paths),'sample_vermagic_paths':[module_paths[0],module_paths[-1]],'limitation':'All dependency paths checked; only two ELF/vermagic samples after decompression; modules never loaded.'})
firmware=json.loads(Path('records/sources/firmware-files.json').read_text());fw_count=0
for package,files in firmware.items():
 for path,expected in files.items():assert sha(read(path))==expected,path;fw_count+=1
save('firmware-summary.json',{'verified_paths':fw_count,'packages':list(firmware),'hardware_loading':'UNTESTED'})
rows={}
for paragraph in text('/var/lib/dpkg/status').strip().split('\n\n'):
 entry=email.parser.Parser().parsestr(paragraph);assert entry['Status']=='install ok installed' and entry['Architecture'] in ['arm64','all']
 assert entry['Package'] not in rows;rows[entry['Package']]=[entry['Version'],entry['Architecture'],'installed']
expected={line.split('\t')[0]:line.split('\t')[1:] for line in Path('records/packages.tsv').read_text().splitlines()};assert rows==expected
save('package-summary.json',{'configured_packages':len(rows),'manifest_exact_match':True,'dpkg_updates':ls('/var/lib/dpkg/updates'),'limitation':'No target dpkg/apt execution, network update or fresh package-wide checksum/signature verification.'})
apt={}
for path in ['/etc/apt/sources.list',*[r['path'] for r in walk('/etc/apt/sources.list.d') if r['mode'].startswith('10')]]:
 if stat(path):apt[path]=text(path)
assert not re.search(r'trusted\s*=\s*yes|\b(bookworm|sid)\b','\n'.join(apt.values()),re.I)
save('apt-sources.json',apt)
# Do not persist shadow credentials, keys or passwd personal fields: only derived policy statuses.
shadow=[line.split(':') for line in text('/etc/shadow').splitlines()];assert all(r[1].startswith(('!','*')) for r in shadow)
accounts=[r.split(':') for r in text('/etc/passwd').splitlines()];assert not [r for r in accounts if 1000<=int(r[2])<65534]
absent=['/etc/machine-id','/var/lib/dbus/machine-id','/etc/cm3-cli/owner.json','/root/.ssh','/etc/apt/sources.list.d/cm3-build.list','/usr/share/keyrings/cm3-build.gpg','/opt/cm3-repo','/usr/sbin/policy-rc.d']
for path in absent:assert stat(path) is None,path
assert not any('ssh_host_' in r['path'] for r in ls('/etc/ssh'))
critical=['/etc/passwd','/etc/shadow','/etc/group','/etc/gshadow','/etc/sudoers','/etc/sudoers.d','/etc/cm3-cli','/root','/etc/ssh/sshd_config',*verification['board_policy_sha256']]
permissions={p:stat(resolve(p)) for p in critical}
for path,m in permissions.items():
 assert m and m['uid']==0 and not int(m['mode'],8)&0o022,path
for path,expected in verification['board_policy_sha256'].items():assert sha(read(path))==expected,path
with Path('/opt/data/artifacts/cm3-qualification/t_ce5ca21d/cm3-trixie-arm64-cli.img').open('rb') as raw:
 for name,offset in [('idblock.img',64*512),('idblock.img',136*4096),('u-boot.itb',16384*512)]:
  b=read('/usr/lib/u-boot/radxa-cm3-rpi-cm4-io/'+name);raw.seek(offset);assert raw.read(len(b))==b
  assert offset+len(b)<=parts[0]['offset']
save('loader-placements.json',{'placements_checked':3,'raw_bytes_equal_installed_loaders':True,'partition_overlap':False,'boot_execution':'UNTESTED'})
save('account-security-summary.json',{'password_entries':len(shadow),'all_passwords_locked':True,'regular_users':0,'machine_id_host_keys_owner_and_build_artifacts_absent':True,'absent_paths':absent,'permissions':permissions,'limitation':'Focused policy/permissions check, not exhaustive filesystem/secret/capability audit. Readiness/account tools never executed.'})
units=walk('/etc/systemd/system');links={};unit_contents={}
for row in units:
 if row['mode'].startswith('12'):
  path=row['path'];m=stat(path);links[path]=m
  if m['link']=='/dev/null':continue
  resolved=resolve(path);assert stat(resolved),path
for path in contract.SERVICE_LINKS:assert '/etc/systemd/system/'+path in links
for path in ['/usr/lib/systemd/system/cm3-cli-enroll.service','/usr/lib/systemd/system/cm3-cli-firewall.service','/etc/systemd/system/ssh.service.d/cm3-cli.conf','/usr/lib/systemd/system/NetworkManager.service.d/cm3-cli.conf','/etc/ssh/sshd_config.d/00-cm3-cli.conf']:
 unit_contents[path]=text(path)
assert links['/etc/systemd/system/ssh.socket']['link']=='/dev/null'
assert links['/etc/systemd/system/default.target']['link']=='/usr/lib/systemd/system/multi-user.target'
save('systemd-unit-inventory.json',{'entries':units,'symlinks':links,'policy_contents':unit_contents,'limitation':'Enabled wants/aliases/masks inspected offline; generator output, dependency cycles and actual activation UNTESTED.'})
# Inventory lifecycle hooks as text/hash evidence. No installation/recovery commands execute.
paths=[]
for directory in ['/usr/lib/cm3-cli','/etc/kernel','/etc/initramfs','/etc/initramfs-tools','/usr/share/initramfs-tools/hooks','/usr/share/initramfs-tools/scripts','/usr/lib/bootloader','/usr/lib/u-boot','/usr/lib/systemd/system-generators']:
 if stat(resolve(directory)):paths+=walk(resolve(directory))
paths += [r for r in ls('/var/lib/dpkg/info') if 'cm3-cli-board-support.' in r['path']]
paths += [r for r in ls('/usr/sbin') if any(word in r['path'] for word in ['grow','resize','u-boot','flash'])]
save('lifecycle-inventory.json',paths)
script_text={}
for row in paths:
 m=stat(resolve(row['path']))
 if m and m['type']=='regular' and int(row['size'] or 0)<100000:
  b=read(row['path'])
  if b.startswith(b'#!') or row['path'].endswith(('.service','.conf','.ps1')):script_text[row['path']]=b.decode(errors='replace')
save('lifecycle-script-text.json',script_text)
matrix=Path('records/sources/hardware-matrix.tsv').read_bytes();assert sha(matrix)=='24c30e0964dcec3326c723ad8f8b84c39104ff7a8688f33a7e997b2ef2098232'
assert matrix==Path('prior/hardware-matrix.tsv').read_bytes()
matrows=[line.split('\t') for line in matrix.decode().splitlines()[1:]];assert len(matrows)==28 and all(r[4]=='UNTESTED' for r in matrows)
(OUT/'hardware-matrix.tsv').write_bytes(matrix)
save('commands.json',commands)
save('summary.json',{'status':'STATIC PASS for focused offline checks; no hardware/release approval','packages':len(rows),'firmware_paths':fw_count,'module_dependency_paths':len(references),'initramfs_members':len(members),'systemd_symlinks_including_masks_and_aliases':len(links),'lifecycle_entries':len(paths),'hardware_rows_untested':len(matrows),'no_target_code_executed':True})
print((OUT/'summary.json').read_text())
