"""Workspace-only preparation; never mounts or writes the retained image."""
from pathlib import Path
import hashlib,json,zipfile,urllib.request,subprocess,os,struct,zlib,uuid,shutil
W=Path(__file__).resolve().parent
os.chdir(W)
def digest(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  while b:=f.read(4*1024*1024): h.update(b)
 return h.hexdigest()
base=Path('/opt/data/artifacts/cm3-qualification/t_ce5ca21d')
expected={'cm3-trixie-arm64-cli.img':'b0d1f56240fafc49cc32ceab0f041d4bb6f529604635684135ccc6ad26ebbff8','cm3-trixie-arm64-cli.img.xz':'6b72f1005c517309e9647e7c65d2344ee31e013da0e2f4ae5a07c4f2afcd8037','retained-image-sources.zip':'cac0f8575b91529e4809d86a99fb460b2279acc19fd8eea56469dca51d959fad'}
identities={}
for name,value in expected.items():
 p=base/name; actual=digest(p);assert actual==value,(name,actual)
 identities[name]={'path':str(p),'sha256':actual,'bytes':p.stat().st_size,'mode':oct(p.stat().st_mode & 0o777)}
Path('identities-before.json').write_text(json.dumps(identities,indent=2))
records=Path('records');records.mkdir(exist_ok=True)
with zipfile.ZipFile(base/'retained-image-sources.zip') as z:
 for n in z.namelist():
  p=Path(n);assert not p.is_absolute() and '..' not in p.parts
  if n.endswith('/') or n.endswith('.img.xz') or n.endswith('.tar.gz') or n.startswith('sources/debian-sources/'):continue
  dest=records/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z.read(n))
 # Extract ONLY regular builder source files, never arbitrary archive links.
 import tarfile
 with z.open('sources/modified-bsp-and-builder-sources.tar.gz') as stream,tarfile.open(fileobj=stream,mode='r|gz') as tar:
  for m in tar:
   if m.isfile() and m.name.startswith('builder-and-board/'):
    p=Path(m.name.removeprefix('builder-and-board/'));assert not p.is_absolute() and '..' not in p.parts
    dest=Path('built-source')/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(tar.extractfile(m).read())
parts=[];raw=base/'cm3-trixie-arm64-cli.img';size=raw.stat().st_size
with raw.open('rb') as f:
 assert f.read(512)[510:]==b'\x55\xaa'
 arrays=[]
 for lba in [1,size//512-1]:
  f.seek(lba*512);header=f.read(512);assert header[:8]==b'EFI PART'
  n,crc=struct.unpack_from('<II',header,12);assert 92<=n<=512
  h=bytearray(header[:n]);h[16:20]=b'\0'*4;assert zlib.crc32(h)==crc
  arr_lba,count,entry_size,arr_crc=struct.unpack_from('<QIII',header,72)
  assert count*entry_size<=1024*1024
  f.seek(arr_lba*512);entries=f.read(count*entry_size);assert zlib.crc32(entries)==arr_crc;arrays.append(entries)
  if lba==1:
   for i in range(count):
    e=entries[i*entry_size:(i+1)*entry_size]
    if e[:16]==bytes(16):continue
    start,end=struct.unpack_from('<QQ',e,32);assert start<=end<size//512
    parts.append({'number':i+1,'start_lba':start,'end_lba':end,'offset':start*512,'bytes':(end-start+1)*512,'alignment_1MiB':start%2048==0,'partuuid':str(uuid.UUID(bytes_le=e[16:32])),'type_guid':str(uuid.UUID(bytes_le=e[:16])),'name':e[56:128].decode('utf-16le').rstrip('\0')})
 assert arrays[0]==arrays[1] and len(parts)==3
 for part in parts:
  f.seek(part['offset']);target=Path('rootfs.ext4' if part['number']==3 else f"fat{part['number']}.img")
  with target.open('wb') as out:
   left=part['bytes']
   while left:
    b=f.read(min(left,4*1024*1024));assert b;out.write(b);left-=len(b)
Path('partition-table.json').write_text(json.dumps(parts,indent=2))
tools=Path('tools');tools.mkdir(exist_ok=True);sources=[]
for package in ['e2fsprogs','libext2fs2t64','libcom-err2','libss2','dosfstools']:
 version='4.2-1.2' if package=='dosfstools' else '1.47.2-3+b12'
 pool='d/dosfstools' if package=='dosfstools' else 'e/e2fsprogs'
 name=f'{package}_{version}_arm64.deb';url=f'https://deb.debian.org/debian/pool/main/{pool}/{name}'
 p=tools/name
 if not p.exists():urllib.request.urlretrieve(url,p)
 sources.append({'url':url,'sha256':digest(p),'bytes':p.stat().st_size})
 subprocess.run(['dpkg-deb','-x',str(p),str(tools/'root')],check=True)
Path('tool-downloads.json').write_text(json.dumps(sources,indent=2))
print(json.dumps({'identities':identities,'partitions':parts,'tools':sources},indent=2))
