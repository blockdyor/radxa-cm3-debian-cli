import pathlib,json
exec(pathlib.Path('inspect.py').read_text().split("contract=mod(")[0])
listing=dbg('ls -p /etc/apt/sources.list.d')[0]; files=[]
for line in listing.splitlines():
 fields=line.split('/')
 if len(fields)>5 and fields[5] not in ['.','..','']:
  files.append('/etc/apt/sources.list.d/'+fields[5])
if stat('/etc/apt/sources.list'):files.append('/etc/apt/sources.list')
result={}
for path in files:
 content=text(path)
 assert 'trusted=yes' not in content and 'bookworm' not in content and ' sid' not in content
 assert 'cm3-repo' not in content
 result[path]={'sha256':sha(content.encode()),'debian_trixie_only':True}
 assert all('trixie' in line or not line.startswith(('deb ','Suites:')) for line in content.splitlines())
assert result
pathlib.Path('runtime-apt-inspection.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
