import os, subprocess, urllib.request, pathlib, json
os.environ['GH_CONFIG_DIR']='/opt/data/home/.config/gh'
token=subprocess.check_output(['/opt/data/home/.local/bin/gh','auth','token'],text=True).strip()
base='https://api.github.com/repos/blockdyor/radxa-cm3-debian-cli/actions/artifacts/'
for aid,name in [(13044838581,'candidate.zip'),(13044604426,'attestation.zip')]:
    p=pathlib.Path(name)
    offset=p.stat().st_size if p.exists() else 0
    meta=json.loads(subprocess.check_output(['/opt/data/home/.local/bin/gh','api',f'repos/blockdyor/radxa-cm3-debian-cli/actions/artifacts/{aid}']))
    pathlib.Path(f'artifact-{aid}.json').write_text(json.dumps(meta,indent=2))
    if offset==meta['size_in_bytes']: continue
    req=urllib.request.Request(base+str(aid)+'/zip',headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json'})
    # Resolve authorization redirect separately; never forward the token to storage.
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self,*args): return None
    try:
        urllib.request.build_opener(NoRedirect).open(req,timeout=60)
        raise RuntimeError('expected storage redirect')
    except urllib.error.HTTPError as e:
        if e.code!=302: raise
        url=e.headers['Location']
    req=urllib.request.Request(url,headers={'Range':f'bytes={offset}-'} if offset else {})
    with urllib.request.urlopen(req,timeout=120) as r:
        if offset and r.status!=206: raise RuntimeError('resume not supported')
        with p.open('ab' if offset else 'wb') as out:
            while chunk:=r.read(1024*1024): out.write(chunk)
    assert p.stat().st_size==meta['size_in_bytes']
    print(name,'retrieved',p.stat().st_size,flush=True)
