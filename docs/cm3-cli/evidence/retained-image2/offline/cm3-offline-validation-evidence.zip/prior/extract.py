import pathlib,zipfile,hashlib,json,lzma
out=pathlib.Path('retained'); out.mkdir(exist_ok=True)
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(4*1024*1024):h.update(b)
 return h.hexdigest()
results={}
for name,aid in [('candidate.zip',13044838581),('attestation.zip',13044604426)]:
 p=pathlib.Path(name); meta=json.loads(pathlib.Path(f'artifact-{aid}.json').read_text()); h=digest(p)
 assert meta['digest']=='sha256:'+h
 results[name]={'bytes':p.stat().st_size,'sha256':h}
 with zipfile.ZipFile(p) as z:
  assert len(z.namelist())==len(set(z.namelist()))
  for info in z.infolist():
   dest=out/info.filename
   assert not pathlib.PurePosixPath(info.filename).is_absolute() and '..' not in pathlib.PurePosixPath(info.filename).parts
   assert info.file_size < 2_000_000_000
   dest.parent.mkdir(parents=True,exist_ok=True)
   with z.open(info) as f,dest.open('wb') as w:
    while b:=f.read(4*1024*1024): w.write(b)
  results[name]['members']=len(z.infolist())
print(json.dumps(results,indent=2),flush=True)
pathlib.Path('retrieval-results.json').write_text(json.dumps(results,indent=2))
print('TOP LEVEL',sorted(p.name for p in out.iterdir()),flush=True)
p=out/'cm3-trixie-arm64-cli.img.xz'; raw=out/'cm3-trixie-arm64-cli.img'; h=hashlib.sha256();size=0
with lzma.open(p,'rb') as f,raw.open('wb') as w:
 while b:=f.read(4*1024*1024):
  size+=len(b)
  assert size<=1730675712,'decompression size cap'
  h.update(b); w.write(b)
result={'compressed_bytes':p.stat().st_size,'compressed_sha256':digest(p),'raw_bytes':size,'raw_sha256':h.hexdigest()}
pathlib.Path('image-identities.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
