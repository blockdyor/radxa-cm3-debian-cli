import pathlib,subprocess,os,json,hashlib,re,struct,uuid,importlib.util,posixpath,email.parser,tarfile,io,zlib
P=pathlib.Path; os.environ['LD_LIBRARY_PATH']=str(P('tools/root/usr/lib/aarch64-linux-gnu').resolve())
repo=P('repo').resolve(); retained=P('retained'); data=P('inspection-private');data.mkdir(exist_ok=True)
report={};meta_cache={};read_cache={}
def sha(b):return hashlib.sha256(b).hexdigest()
def dbg(cmd):
 r=subprocess.run(['tools/root/usr/sbin/debugfs','-R',cmd,'rootfs.ext4'],capture_output=True,text=True,check=True)
 return r.stdout,r.stderr
def stat(path):
 if path not in meta_cache:
  s,e=dbg('stat '+json.dumps(path))
  if 'Inode:' not in s:meta_cache[path]=None
  else:
   typ=re.search(r'Type: (\w+)\s+Mode:\s+(\d+)',s); owner=re.search(r'User:\s+(\d+)\s+Group:\s+(\d+)',s)
   link=re.search(r'Fast link dest: "(.*)"',s)
   meta_cache[path]={'type':typ[1],'mode':int(typ[2],8),'uid':int(owner[1]),'gid':int(owner[2]),'link':link[1] if link else None}
 return meta_cache[path]
def resolve(path,follow=True):
 path=posixpath.normpath(path); bits=path.strip('/').split('/');current=''
 for i,bit in enumerate(bits):
  current+='/'+bit;m=stat(current)
  if m is None:return current+('/'+'/'.join(bits[i+1:]) if i+1<len(bits) else '')
  if m['type']=='symlink' and (follow or i<len(bits)-1):
   target=m['link'];assert target is not None,'long symlink not supported'
   return resolve(posixpath.join(posixpath.dirname(current),target,*bits[i+1:]),follow)
 return current
counter=0
def read(path):
 global counter
 path=resolve(path)
 if path not in read_cache:
  assert stat(path) and stat(path)['type']=='regular',path
  counter+=1; dest=data/str(counter)
  s,e=dbg('dump '+json.dumps(path)+' '+str(dest));assert dest.exists(),(path,s,e)
  read_cache[path]=dest.read_bytes()
 return read_cache[path]
def text(path):return read(path).decode()
def mod(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
contract=mod('contract',repo/'scripts/cm3-image-contract.py')
parts=json.loads(P('gpt-inspection.json').read_text());raw=retained/'cm3-trixie-arm64-cli.img'
report['layout']=contract.layout(parts,raw.stat().st_size,512,'gpt')
uuids=[]
with raw.open('rb') as f:
 for n,part in enumerate(parts):
  f.seek(part['part_start']);b=f.read(2048)
  if n<2:
   assert b[510:512]==b'\x55\xaa' and b'FAT' in b[54:90]
   fat32=struct.unpack_from('<H',b,17)[0]==0; serial=struct.unpack_from('<I',b,67 if fat32 else 39)[0]
   u=f'{serial:08X}';uuids.append(u[:4]+'-'+u[4:])
  else:
   assert b[1080:1082]==b'\x53\xef';uuids.append(str(uuid.UUID(bytes=b[1128:1144])))
report['boot']=contract.boot(text('/boot/extlinux/extlinux.conf'),text('/etc/kernel/cmdline'),text('/etc/fstab'),uuids)
osrel=text('/etc/os-release');assert 'ID=debian' in osrel.splitlines() and 'VERSION_CODENAME=trixie' in osrel.splitlines()
verification=json.loads((retained/'verification.json').read_text())
for path,digest in verification['boot_file_sha256'].items():assert sha(read(path))==digest
kernel=read(report['boot']['paths']['linux'][0]);assert kernel[56:60]==b'ARM\x64'
dtb=read(report['boot']['paths']['fdt'][0]);assert dtb[:4]==b'\xd0\x0d\xfe\xed' and b'radxa,cm3-rpi-cm4-io\x00' in dtb and b'rockchip,rk3566\x00' in dtb
# Parse the actual installed inventory independently of the retained status assertion.
rows={}
for para in text('/var/lib/dpkg/status').strip().split('\n\n'):
 p=email.parser.Parser().parsestr(para);assert p['Status']=='install ok installed'
 name=p['Package'];assert name not in rows and p['Architecture'] in ['arm64','all']
 assert not name.startswith(('task-','xserver-','gdm','lightdm','casaos','yunohost','docker'))
 rows[name]=[p['Version'],p['Architecture'],'installed']
manifest={r[0]:r[1:] for r in [line.split('\t') for line in (retained/'packages.tsv').read_text().splitlines()]};assert rows==manifest
for package in ['apt','dpkg','systemd','libc6','apparmor','cm3-cli-board-support']:assert package in rows
report['packages']=len(rows)
for path in ['/etc/machine-id','/var/lib/dbus/machine-id','/etc/cm3-cli/owner.json','/etc/apt/sources.list.d/cm3-build.list','/usr/share/keyrings/cm3-build.gpg','/opt/cm3-repo','/root/.ssh','/usr/sbin/policy-rc.d']:
 assert stat(resolve(path,False)) is None,path
for line in text('/etc/shadow').splitlines():assert line.split(':')[1].startswith(('!','*'))
assert stat('/etc/systemd/system/default.target')['link']=='/usr/lib/systemd/system/multi-user.target'
for service in contract.SERVICE_LINKS:assert stat('/etc/systemd/system/'+service)['type']=='symlink'
sshlist=dbg('ls -p /etc/ssh')[0];assert 'ssh_host_' not in sshlist
board=mod('board',repo/'packages/cm3-cli-board-support/build.py')
boardfiles={name:board.HERE/'root'/name for name in board.PAYLOAD}
boardfiles['usr/lib/cm3-cli/owner_config.py']=repo/'scripts/cm3-owner-config.py'
boardfiles['usr/share/doc/cm3-cli-board-support/README']=repo/'packages/cm3-cli-board-support/README'
boardfiles['usr/share/doc/cm3-cli-board-support/copyright']=repo/'LICENSE'
for name,source in boardfiles.items():
 path='/'+name;actual=read(path);m=stat(resolve(path));expected=0o755 if name in ['usr/lib/cm3-cli/enroll.py','usr/lib/cm3-cli/boot-update'] else 0o644
 assert m['mode']==expected and m['uid']==m['gid']==0 and actual==source.read_bytes(),path
report['board_policy_files']=len(boardfiles)
with raw.open('rb') as f:
 for name,offset in [('idblock.img',64*512),('idblock.img',136*4096),('u-boot.itb',16384*512)]:
  b=read('/usr/lib/u-boot/'+contract.PRODUCT+'/'+name);f.seek(offset);assert f.read(len(b))==b and offset+len(b)<=parts[0]['part_start']
report['loader_placements']=3
for n in [1,2]:
 r=subprocess.run(['tools/root/usr/bin/mdir','-i',f'fat{n}.img','::'],capture_output=True,text=True);assert r.returncode==0,r.stderr
 report[f'fat{n}']=r.stdout
# All checksums cover downloaded bytes, not a copied build-worker verdict.
delivery=json.loads((retained/'delivery-result.json').read_text())
for name,digest in delivery['files'].items():
 p=retained/name;assert p.is_file() and sha(p.read_bytes())==digest,name
report['delivery_hashes']=len(delivery['files'])
source_report=json.loads((retained/'sources/delivery-inputs.json').read_text())
for name,digest in source_report['files'].items():assert sha((retained/'sources'/name).read_bytes())==digest,name
report['source_hashes']=len(source_report['files'])
for line in (retained/'SHA256SUMS').read_text().splitlines():
 digest,name=line.split(None,1);name=name.strip().lstrip('*');assert sha((retained/name).read_bytes())==digest,name
report['sha256sums']='PASS'
# Firmware bytes and notices are checked against the installed filesystem, including merged-/usr aliases.
firmware=json.loads((retained/'sources/firmware-files.json').read_text())
for package,files in firmware.items():
 for path,digest in files.items():assert sha(read(path))==digest,path
report['firmware_paths']=sum(map(len,firmware.values()))
notices=tarfile.open(retained/'sources/installed-notices.tar.gz')
for package in rows:
 path='usr/share/doc/'+package+'/copyright'
 try:m=notices.getmember(path)
 except KeyError:continue
 if m.isfile():assert read('/'+path)==notices.extractfile(m).read(),path
review=json.loads((retained/'sources/notice-review.json').read_text())
for package,entry in review['firmware'].items():
 assert rows[package][0]==entry['version']=='20250410-2'
 assert sha(read('/usr/share/doc/'+package+'/copyright'))==entry['copyright_sha256']
assert sha(read('/usr/share/doc/radxa-overlays-dkms/copyright'))==review['overlay_copyright_sha256']
assert b'GPL-2, unless otherwise noted' in read('/usr/share/doc/radxa-overlays-dkms/copyright')
report['notice_review']='installed firmware/overlay notice bytes match preserved archive and reviewed hashes'
# Check all DSC source closure payload hashes, and installed non-local source identities.
dscs={};dsc_hashes=0
for path in (retained/'sources/debian-sources').glob('*.dsc'):
 p=email.parser.Parser().parsestr(path.read_text().split('\n\n',1)[1] if path.read_text().startswith('-----BEGIN') else path.read_text())
 dscs[p['Source']]=p['Version']
 for line in p['Checksums-Sha256'].splitlines():
  if not line.strip():continue
  digest,size,name=line.split();b=(path.parent/name).read_bytes();assert len(b)==int(size) and sha(b)==digest;dsc_hashes+=1
source_rows=[r.split('\t') for r in (retained/'sources/installed-source-identities.tsv').read_text().splitlines()]
assert {r[0]:(r[1],r[2]) for r in source_rows}=={n:tuple(v[:2]) for n,v in rows.items()}
local=set(entry.split('=')[0] for entry in json.loads((retained/'image-stage-a.json').read_text())['receipt']['packages'])
for name,version,arch,source,source_version in source_rows:
 if name not in local:assert dscs[source]==source_version,(name,source,source_version)
report['debian_source_packages']=len(dscs);report['dsc_payload_hashes']=dsc_hashes
lock=(retained/'sources/source-lock.json').read_bytes();assert lock==(repo/'project/cm3-cli/source-lock.json').read_bytes()
# Stream the complete corresponding-source TAR without extracting untrusted links or executing files.
source_members=0;builder_matches=0;config=None;loader_checked=set();required_source_paths=set()
loader_record=json.loads((retained/'sources/loader-inputs.json').read_text())
required={'generated/kernel.config','generated/u-boot.config','linux-rk2410-nocsf/src/COPYING','linux-rk2410-nocsf/Makefile','u-boot-rk2601/Makefile','radxa-overlays/debian/copyright'}
with tarfile.open(retained/'sources/modified-bsp-and-builder-sources.tar.gz',mode='r|gz') as tar:
 for m in tar:
  source_members+=1;assert not m.name.startswith('/') and '..' not in pathlib.PurePosixPath(m.name).parts
  assert not any(x in pathlib.PurePosixPath(m.name).parts for x in ['.git','.ssh','.env'])
  assert m.name!='builder-and-board/project/cm3-cli/retention-recipient.pem'
  if m.name in required:required_source_paths.add(m.name)
  if not m.isfile():continue
  stream=tar.extractfile(m)
  if m.name.startswith('u-boot-rk2601/rkbin/') and m.name.removeprefix('u-boot-rk2601/rkbin/') in loader_record['sha256']:
   name=m.name.removeprefix('u-boot-rk2601/rkbin/');b=stream.read()
   if name=='RKBOOT/RK3566MINIALL.ini':
    original=P('original-loader.ini').read_bytes();assert sha(original)==loader_record['sha256'][name]
    transformed=re.sub(rb'^FlashBoot=.*$',b'FlashBoot=../src/spl/u-boot-spl.bin',original,flags=re.M)
    transformed=re.sub(rb'^PATH=.*$',b'PATH=rkboot.bin',transformed,flags=re.M)
    assert b==transformed
    report['loader_ini_transformation']={'original_sha256':sha(original),'retained_post_build_sha256':sha(b),'result':'exact documented pinned recipe FlashBoot/PATH transformation; not byte drift in blobs'}
   else:assert sha(b)==loader_record['sha256'][name]
   loader_checked.add(name)
   if name=='LICENSE':assert b==read('/usr/share/doc/u-boot-rk2601/LICENSE')
  elif m.name.startswith('builder-and-board/'):
   name=m.name.removeprefix('builder-and-board/');b=stream.read()
   expected=subprocess.check_output(['git','-C',str(repo),'show','2b41b830cae9efc313f3d39d85be265b6e3eae25:'+name]);assert b==expected,name;builder_matches+=1
  elif m.name=='generated/kernel.config':config=stream.read().decode()
  elif m.name=='radxa-overlays/debian/copyright':assert stream.read()==read('/usr/share/doc/radxa-overlays-dkms/copyright')
  else:
   while stream.read(1024*1024):pass
assert required_source_paths==required and loader_checked==set(loader_record['sha256'])
assert config and 'CONFIG_ARM64=y' in config and 'CONFIG_SECURITY_APPARMOR=y' in config
probe=mod('source_probe',repo/'scripts/cm3-source-preflight.py');probe.verify_kernel_config(config)
assert text('/boot/config-6.1.84-18+cm3cli1-rk2410-nocsf')==config
assert read('/usr/bin/bash')[:4]==b'\x7fELF' and struct.unpack_from('<H',read('/usr/bin/bash'),18)[0]==183
report['loader_input_hashes']=len(loader_checked)
report['kernel_config_capabilities']='PASS — compiled intent only; active runtime UNTESTED'
report['source_archive_members']=source_members;report['builder_files_exact_built_commit']=builder_matches
matrix=(retained/'sources/hardware-matrix.tsv').read_text();matrix_rows=[r.split('\t') for r in matrix.splitlines()[1:]];assert len(matrix_rows)==28 and all(r[4]=='UNTESTED' for r in matrix_rows)
assert (retained/'sources/hardware-matrix.tsv').read_bytes()==(repo/'docs/cm3-cli/hardware-matrix.tsv').read_bytes()
report['hardware_rows_untested']=len(matrix_rows)
report['status']='PASS — independent retained-image offline inspection only'
P('independent-inspection.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
