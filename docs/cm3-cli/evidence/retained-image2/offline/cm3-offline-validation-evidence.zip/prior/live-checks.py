import os,pathlib,json,subprocess,urllib.request,urllib.parse,hashlib,datetime
os.environ['GH_CONFIG_DIR']='/opt/data/home/.config/gh'
gh='/opt/data/home/.local/bin/gh';repo='blockdyor/radxa-cm3-debian-cli'
def api(path):return json.loads(subprocess.check_output([gh,'api',f'repos/{repo}/'+path]))
r={}
r['checked_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
r['pr']=json.loads(subprocess.check_output([gh,'pr','view','1','--repo',repo,'--json','headRefOid,isDraft,state,url']))
head=r['pr']['headRefOid'];assert head=='dfafa5e85586b8cbf330888077e6ecefb659b585'
r['artifacts']=[api('actions/artifacts/'+str(a)) for a in [13044838581,13044604426]]
for a in r['artifacts']:assert not a['expired'] and a['expires_at']>'2026-10-31T00:00:00Z'
r['run']=api('actions/runs/41199013085');assert r['run']['conclusion']=='success' and r['run']['head_sha']=='2b41b830cae9efc313f3d39d85be265b6e3eae25'
checks=api(f'commits/{head}/check-runs')['check_runs'];sonar=[c for c in checks if c['name']=='SonarCloud Code Analysis'];assert len(sonar)==1 and sonar[0]['conclusion']=='success'
r['head_sonar']={k:sonar[0][k] for k in ['name','head_sha','status','conclusion','completed_at','details_url']}
for label,url in {
 'sonar_gate':'https://sonarcloud.io/api/qualitygates/project_status?projectKey=blockdyor_radxa-cm3-debian-cli&pullRequest=1',
 'sonar_issues':'https://sonarcloud.io/api/issues/search?componentKeys=blockdyor_radxa-cm3-debian-cli&pullRequest=1&resolved=false&ps=1',
 'sonar_hotspots':'https://sonarcloud.io/api/hotspots/search?projectKey=blockdyor_radxa-cm3-debian-cli&pullRequest=1&ps=1'
}.items():
 try:
  j=json.load(urllib.request.urlopen(url,timeout=40));pathlib.Path(label+'.json').write_text(json.dumps(j,indent=2));r[label]='retrieved'
 except urllib.error.HTTPError as e:r[label]='HTTP '+str(e.code)
args=[gh,'attestation','verify','retained/delivery-result.json','--bundle','retained/_temp/cREnro/attestation.json','--repo',repo,'--signer-workflow',repo+'/.github/workflows/build.yaml','--source-digest','2b41b830cae9efc313f3d39d85be265b6e3eae25','--signer-digest','2b41b830cae9efc313f3d39d85be265b6e3eae25','--source-ref','refs/heads/dev/cm3-debian-cli','--deny-self-hosted-runners','--format','json']
tamper=pathlib.Path('tampered-delivery.json');tamper.write_bytes(pathlib.Path('retained/delivery-result.json').read_bytes()+b'\n')
negative=args.copy();negative[3]=str(tamper)
p=subprocess.run(negative,capture_output=True,text=True);assert p.returncode!=0;r['tampered_subject_rejected']=True
negative=args.copy();negative[negative.index('--source-digest')+1]='0'*40
p=subprocess.run(negative,capture_output=True,text=True);assert p.returncode!=0;r['wrong_source_rejected']=True
pathlib.Path('final-live-state.json').write_text(json.dumps(r,indent=2))
print(json.dumps({k:v for k,v in r.items() if k not in ['artifacts','run']},indent=2));print('artifacts:',[(a['id'],a['expired'],a['expires_at']) for a in r['artifacts']])
