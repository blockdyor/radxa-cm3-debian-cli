import tarfile,json,hashlib,pathlib
p=pathlib.Path('retained/sources');r=json.loads((p/'loader-inputs.json').read_text());checked={}
with tarfile.open(p/'modified-bsp-and-builder-sources.tar.gz','r|gz') as t:
 for m in t:
  name=m.name.removeprefix('u-boot-rk2601/rkbin/')
  if m.isfile() and m.name.startswith('u-boot-rk2601/rkbin/') and name in r['sha256']:
   b=t.extractfile(m).read();h=hashlib.sha256(b).hexdigest();checked[name]={'actual':h,'recorded':r['sha256'][name],'equal':h==r['sha256'][name]}
   if h!=r['sha256'][name] and len(b)<10000:print(name,b.decode(errors='replace'))
print(json.dumps(checked,indent=2));pathlib.Path('loader-source-review.json').write_text(json.dumps(checked,indent=2))
