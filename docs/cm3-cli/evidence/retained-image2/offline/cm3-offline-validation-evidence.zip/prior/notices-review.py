import pathlib,json,tarfile,hashlib
# Reuse only the read-only file access helpers, not the prior verdict.
exec(pathlib.Path('inspect.py').read_text().split("contract=mod(")[0])
count=0;common=0
with tarfile.open('retained/sources/installed-notices.tar.gz','r|gz') as t:
 for m in t:
  if m.isfile() and (m.name.endswith('/copyright') or m.name.startswith('usr/share/common-licenses/')):
   assert t.extractfile(m).read()==read('/'+m.name),m.name
   count+=int(m.name.endswith('/copyright'));common+=int(m.name.startswith('usr/share/common-licenses/'))
firmware={}
with tarfile.open('retained/sources/debian-sources/firmware-nonfree_20250410.orig.tar.xz','r|xz') as t:
 for m in t:
  if m.isfile() and (m.name.endswith('/WHENCE') or m.name.endswith('/LICENCE.cypress')):
   b=t.extractfile(m).read();firmware[m.name]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
   if m.name.endswith('/WHENCE'):assert b'brcmfmac4354-sdio.nvidia,p2371-2180.txt' in b
assert len(firmware)==2
r={'copyright_files_matched_to_image':count,'common_license_texts_matched_to_image':common,'firmware_original_source_notice_records':firmware}
pathlib.Path('additional-notice-inspection.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
