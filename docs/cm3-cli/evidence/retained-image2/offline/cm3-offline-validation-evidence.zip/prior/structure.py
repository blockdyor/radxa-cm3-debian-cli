from pathlib import Path
import struct,zlib,json,subprocess,os,hashlib
p=Path('retained/cm3-trixie-arm64-cli.img');size=p.stat().st_size
with p.open('rb') as f:
 assert f.read(512)[510:]==b'\x55\xaa'
 parts=[]
 for lba in [1,size//512-1]:
  f.seek(lba*512); header=f.read(512); assert header[:8]==b'EFI PART'
  n=struct.unpack_from('<I',header,12)[0]; crc=struct.unpack_from('<I',header,16)[0]
  h=bytearray(header[:n]);h[16:20]=b'\0'*4;assert zlib.crc32(h)==crc
  arr_lba,count,entry_size,arr_crc=struct.unpack_from('<QIII',header,72)
  f.seek(arr_lba*512); entries=f.read(count*entry_size);assert zlib.crc32(entries)==arr_crc
  if lba==1:
   for i in range(count):
    e=entries[i*entry_size:(i+1)*entry_size]
    if e[:16]==b'\0'*16:continue
    start,end=struct.unpack_from('<QQ',e,32)
    parts.append({'part_num':i+1,'part_start':start*512,'part_end':end*512+511,'part_size':(end-start+1)*512})
  else: assert entries==primary
  primary=entries
 for part in parts:
  f.seek(part['part_start'])
  target=Path('rootfs.ext4' if part['part_num']==3 else f"fat{part['part_num']}.img")
  with target.open('wb') as out:
   remaining=part['part_size']
   while remaining:
    b=f.read(min(4*1024*1024,remaining));assert b;out.write(b);remaining-=len(b)
Path('gpt-inspection.json').write_text(json.dumps(parts,indent=2));print(parts)
os.environ['LD_LIBRARY_PATH']=str(Path('tools/root/usr/lib/aarch64-linux-gnu').resolve())
for cmd in [['tools/root/usr/sbin/debugfs','-R','stat /etc/os-release','rootfs.ext4'],['tools/root/usr/sbin/debugfs','-R','stat /etc/systemd/system/default.target','rootfs.ext4'],['tools/root/usr/sbin/debugfs','-R','ls -p /etc/ssh','rootfs.ext4']]:
 r=subprocess.run(cmd,capture_output=True,text=True);print(r.stdout,r.stderr)
r=subprocess.run(['tools/root/usr/sbin/e2fsck','-fn','rootfs.ext4'],capture_output=True,text=True)
Path('e2fsck-readonly.txt').write_text(r.stdout+r.stderr);print('e2fsck',r.returncode);assert r.returncode==0
