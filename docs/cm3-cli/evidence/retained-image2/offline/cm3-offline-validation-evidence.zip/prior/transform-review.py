import urllib.request,hashlib,pathlib,tarfile,json
root=pathlib.Path('retained/sources');original=urllib.request.urlopen('https://raw.githubusercontent.com/radxa/rkbin/f3e6dd6372377faee13b29d0ce35eb08049356ef/RKBOOT/RK3566MINIALL.ini',timeout=45).read()
print('ORIGINAL',hashlib.sha256(original).hexdigest(),original.decode())
pathlib.Path('original-loader.ini').write_bytes(original)
with tarfile.open(root/'modified-bsp-and-builder-sources.tar.gz','r|gz') as t:
 for m in t:
  if m.name.startswith('u-boot-rk2601/') and '/src/' not in m.name and '/rkbin/' not in m.name and m.isfile() and m.size<100000:
   b=t.extractfile(m).read()
   if b'RK3566MINIALL' in b or b'boot_merger' in b or b'FlashBoot' in b:
    print(m.name,b.decode(errors='replace'));pathlib.Path('recipe-loader-transform.txt').write_text(m.name+'\n'+b.decode())
