EXPERIMENTAL — NOT HARDWARE VALIDATED — NOT FOR PRODUCTION
Source: 2b41b830cae9efc313f3d39d85be265b6e3eae25
Run: https://github.com/blockdyor/radxa-cm3-debian-cli/actions/runs/41199013085
14-day GitHub Actions development artifact; no release or hardware authority.
Original component licenses apply. Sources/notices accompany these exact bytes in sources/.
Rockchip and radio firmware are proprietary; retain their notices and restrictions.
OS expansion is not implemented; maintenance/support ownership and reproducibility remain unqualified.
All physical tests remain UNTESTED. Obtain separate hardware authorization before use.
