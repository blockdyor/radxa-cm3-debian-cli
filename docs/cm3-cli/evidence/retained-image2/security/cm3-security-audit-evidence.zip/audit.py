"""Read-only retained-image security audit. Outputs redact all candidate secret values."""
import os, pathlib, hashlib, subprocess, json, re, stat, platform
W=pathlib.Path(__file__).resolve().parent
os.chdir(W)
os.umask(0o077)
ORIG=pathlib.Path('/opt/data/artifacts/cm3-qualification/t_ce5ca21d')
UP=pathlib.Path('/opt/data/kanban/workspaces/t_6c2ac45f')
DBG=UP/'tools/root/usr/sbin/debugfs'
env=dict(os.environ,LD_LIBRARY_PATH=str(UP/'tools/root/usr/lib/aarch64-linux-gnu'))
OUT=W/'evidence';OUT.mkdir(exist_ok=True)
def save(n,x): (OUT/n).write_text(json.dumps(x,indent=2))
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
expected={'cm3-trixie-arm64-cli.img':'b0d1f56240fafc49cc32ceab0f041d4bb6f529604635684135ccc6ad26ebbff8','cm3-trixie-arm64-cli.img.xz':'6b72f1005c517309e9647e7c65d2344ee31e013da0e2f4ae5a07c4f2afcd8037','retained-image-sources.zip':'cac0f8575b91529e4809d86a99fb460b2279acc19fd8eea56469dca51d959fad'}
assert {n:digest(ORIG/n) for n in expected}==expected
p=W/'rootfs.ext4'
if not p.exists():
 with (ORIG/'cm3-trixie-arm64-cli.img').open('rb') as src,p.open('wb') as dst:
  src.seek(348127232);left=1382531584
  while left:
   b=src.read(min(left,8*1024*1024));assert b;dst.write(b);left-=len(b)
commands=[]
def dbg(cmd):
 r=subprocess.run([str(DBG),'-R',cmd,str(p)],env=env,capture_output=True)
 commands.append({'request':cmd,'exit':r.returncode})
 assert r.returncode==0
 return r.stdout.decode(errors='replace')
root=W/'private-root';root.mkdir(exist_ok=True,mode=0o700)
if not (root/'etc/passwd').exists():
 log=dbg('rdump / '+str(root));save('extraction.json',{'stdout_lines':len(log.splitlines()),'method':'debugfs rdump, no -w; files never executed; symlinks never followed by scanner'})
def read(path):return (root/path.lstrip('/')).read_bytes()
def text(path):return read(path).decode()
# Only paths/category/count leave this private workspace; never persist matching lines or hashes.
patterns={
 'private-key-header':re.compile(rb'-----BEGIN (?:RSA |DSA |EC |OPENSSH |ENCRYPTED )?PRIVATE KEY-----'),
 'github-token-shape':re.compile(rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})\b'),
 'aws-access-key-shape':re.compile(rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b'),
 'credential-url':re.compile(rb'https?://[^\s/:<>"\']+:[^\s/@<>"\']+@'),
 'ssh-public-key-line':re.compile(rb'(?m)^(?:ssh-(?:rsa|ed25519)|ecdsa-sha2-[^ ]+) [A-Za-z0-9+/]{40,}={0,3}(?: |$)'),
}
assert patterns['private-key-header'].search(b'-----BEGIN OPENSSH PRIVATE KEY-----')
assert not patterns['private-key-header'].search(b'BEGIN PUBLIC KEY')
hits=[];files=0;total=0;skipped=[];suspicious=[];permissions=[]
for base,dirs,names in os.walk(root,followlinks=False):
 dirs[:]=[d for d in dirs if not (pathlib.Path(base)/d).is_symlink()]
 for n in names:
  f=pathlib.Path(base)/n;s=f.lstat();name='/'+str(f.relative_to(root))
  if not stat.S_ISREG(s.st_mode):continue
  b=f.read_bytes();files+=1;total+=len(b)
  for category,pat in patterns.items():
   count=len(pat.findall(b))
   if count:hits.append({'path':name,'category':category,'matches':count})
  if re.search(r'(^|/)(authorized_keys|id_rsa|id_ed25519|id_ecdsa|\.netrc|\.git-credentials|auth\.conf|shadow-|gshadow-)(\.|$|/)',name) or re.search(r'(^|/)(\.ssh|\.aws|\.gnupg|\.git)(/|$)',name):suspicious.append({'path':name,'bytes':len(b)})
save('secret-scan.json',{'regular_files':files,'bytes':total,'hits':hits,'suspicious_paths':suspicious,'skipped':skipped,'limits':'Allocated regular-file byte scan only, no opaque/encrypted or compressed-payload recursion, deleted blocks/slack or exhaustive arbitrary-token detection. Package tests/docs can contain fixture markers. No negative result warrants a secret-free guarantee.'})
shadow=[r.split(':') for r in text('/etc/shadow').splitlines()]
accounts=[r.split(':') for r in text('/etc/passwd').splitlines()]
save('accounts.json',{'shadow_entries':len(shadow),'all_password_locked':all(r[1].startswith(('!','*')) for r in shadow),'locked_entries_containing_hash_material':sum(bool(re.search(r'\$[0-9a-z]+\$',r[1])) for r in shadow),'empty_password_entries':sum(r[1]=='' for r in shadow),'interactive_shell_accounts':[{'name':r[0],'uid':r[2],'shell':r[6]} for r in accounts if r[6] not in ['/usr/sbin/nologin','/bin/false','/sbin/nologin']],'regular_uid_accounts':sum(1000<=int(r[2])<65534 for r in accounts),'empty_gshadow_passwords':sum(r.split(':')[1]=='' for r in text('/etc/gshadow').splitlines()),'gshadow_password_hashes':sum(bool(re.search(r'\$[0-9a-z]+\$',r.split(':')[1])) for r in text('/etc/gshadow').splitlines())})
selected={}
prefixes=['etc/ssh','etc/sudoers.d','etc/apt','etc/pam.d','etc/security','etc/cm3-cli','etc/systemd/system/ssh.service.d','etc/systemd/system/sshd-keygen.service.d','etc/apparmor.d','usr/lib/cm3-cli']
for prefix in prefixes:
 d=root/prefix
 if d.exists():
  for f in d.rglob('*'):
   if f.is_symlink() or not f.is_file():continue
   path='/'+str(f.relative_to(root))
   if ('keyring' in path or f.suffix in ['.gpg','.asc'] or path.endswith(('owner.json','auth.conf'))):continue
   b=f.read_bytes()
   if b'\0' not in b and len(b)<250000:selected[path]=b.decode(errors='replace')
for path in ['/etc/sudoers','/etc/login.defs','/etc/kernel/cmdline','/boot/extlinux/extlinux.conf','/usr/lib/systemd/system/cm3-cli-enroll.service','/usr/lib/systemd/system/cm3-cli-firewall.service','/usr/lib/systemd/system/sshd-keygen.service','/usr/lib/systemd/system/ssh.service']:
 if (root/path.lstrip('/')).is_file():selected[path]=text(path)
# Policy texts may contain fixture strings but must not contain a live candidate secret.
for path,value in selected.items():
 assert not any(pat.search(value.encode()) for cat,pat in patterns.items() if cat!='ssh-public-key-line'),path
save('policy-text.json',selected)
config=text('/boot/config-6.1.84-18+cm3cli1-rk2410-nocsf')
save('lsm.json',{'kernel_config':[l for l in config.splitlines() if re.search('CONFIG_(SECURITY|LSM|AUDIT|DEFAULT_SECURITY)',l)],'cmdline':text('/etc/kernel/cmdline'),'apparmor_enabled_link':os.readlink(root/'etc/systemd/system/sysinit.target.wants/apparmor.service'),'runtime_activation':'UNTESTED; neither target kernel nor virtual kernel booted'})
# Metadata comes from debugfs rather than extraction chmod/chown behavior.
metadata={}
for path in ['/etc/shadow','/etc/gshadow','/etc/passwd','/etc/sudoers','/etc/sudoers.d','/etc/ssh/sshd_config','/etc/cm3-cli','/root','/home','/etc/machine-id','/var/lib/dbus/machine-id','/etc/cm3-cli/owner.json']:
 s=dbg('stat '+json.dumps(path));metadata[path]=s if 'Type:' in s else 'ABSENT'
save('metadata.json',metadata)
save('trust-inventory.json',{'paths':[str(f.relative_to(root)) for prefix in ['etc/apt','usr/share/keyrings','var/lib/apt/lists','var/cache/apt/archives'] for f in (root/prefix).rglob('*') if f.is_file() and not f.is_symlink()],'host_key_entries':[f.name for f in (root/'etc/ssh').iterdir() if f.name.startswith('ssh_host_')],'root_ssh_exists':(root/'root/.ssh').exists()})
assert {n:digest(ORIG/n) for n in expected}==expected
save('identity.json',{'original_sha256_before_and_after':expected,'rootfs_sha256':digest(p),'python':platform.python_version(),'machine':platform.machine(),'runtime_executed':False,'rebuilds':0,'target_modified':False})
save('commands.json',commands)
print(json.dumps({'files_scanned':files,'candidate_hits':len(hits),'originals_unchanged':True,'evidence':str(OUT)}))
