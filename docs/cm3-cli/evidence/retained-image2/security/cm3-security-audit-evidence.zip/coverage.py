import pathlib,subprocess,os,re,json,hashlib,zipfile
W=pathlib.Path(__file__).resolve().parent;os.chdir(W);R=W/'private-root';E=W/'evidence';U=pathlib.Path('/opt/data/kanban/workspaces/t_6c2ac45f')
env=dict(os.environ,LD_LIBRARY_PATH=str(U/'tools/root/usr/lib/aarch64-linux-gnu'))
rows=[];pending=['/'];dirs=0
while pending:
 p=pending.pop();dirs+=1
 result=subprocess.run([str(U/'tools/root/usr/sbin/debugfs'),'-R','ls -p '+json.dumps(p),str(W/'rootfs.ext4')],capture_output=True,env=env)
 assert result.returncode==0
 assert not re.search(rb'not found|error|short read|invalid|corrupt',result.stderr,re.I),p
 for line in result.stdout.decode().splitlines():
  fields=line.split('/')
  if len(fields)<7 or not fields[1].isdigit() or not int(fields[1]) or fields[5] in ['.','..']:continue
  name=p.rstrip('/')+'/'+fields[5];mode=int(fields[2],8);size=fields[6]
  if mode&0o170000==0o040000:pending.append(name)
  if mode&0o170000==0o100000:
   target=R/name.lstrip('/');assert not target.is_symlink() and target.is_file(),name
   assert target.stat().st_size==int(size),name
   rows.append({'path':name,'mode':oct(mode),'uid':int(fields[3]),'gid':int(fields[4]),'bytes':int(size)})
scan=json.loads((E/'secret-scan.json').read_text());assert len(rows)==scan['regular_files'];assert sum(r['bytes'] for r in rows)==scan['bytes']
(E/'allocated-file-inventory.json').write_text(json.dumps(rows,indent=2))
summary={'directories_checked':dirs,'allocated_regular_files':len(rows),'byte_count':sum(r['bytes'] for r in rows),'extraction_names_and_sizes_match_image':True,'regular_world_writable':[r['path'] for r in rows if int(r['mode'],8)&2],'suid_sgid_regular_files':[{'path':r['path'],'mode':r['mode']} for r in rows if int(r['mode'],8)&0o6000],'limitation':'Full regular file path/size/mode inventory, not full ACL/xattr/capability or hardlink topology audit.'}
(E/'coverage.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary))
z=zipfile.ZipFile('/opt/data/artifacts/cm3-qualification/t_ce5ca21d/retained-image-sources.zip')
(E/'signature-evidence-inventory.json').write_text(json.dumps({'retained_related_paths':[n for n in z.namelist() if re.search(r'InRelease|Release.gpg|archive-key|signing|authentication|preflight|\.deb$|\.asc$',n)],'fresh_openpgp_verification':False,'note':'Presence inventory is not signature verification; target apt lists/cache are cleaned.'},indent=2))
