"""Verify audit evidence and build a sanitized durable packet; no target code executed."""
import pathlib,json,hashlib,zipfile,platform,re,os
W=pathlib.Path(__file__).resolve().parent;os.chdir(W);E=W/'evidence'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
identity=json.loads((E/'identity.json').read_text())
originals=pathlib.Path('/opt/data/artifacts/cm3-qualification/t_ce5ca21d')
assert {n:sha(originals/n) for n in identity['original_sha256_before_and_after']}==identity['original_sha256_before_and_after']
scan=json.loads((E/'secret-scan.json').read_text());coverage=json.loads((E/'coverage.json').read_text());keys=json.loads((E/'gnutls-key-provenance.json').read_text());account=json.loads((E/'accounts.json').read_text())
assert coverage['allocated_regular_files']==scan['regular_files']==30051
assert coverage['byte_count']==scan['bytes']==871005658
assert not coverage['regular_world_writable']
assert keys['all_blocks_matched'] and keys['complete_private_key_blocks']==8
assert account['all_password_locked'] and account['locked_entries_containing_hash_material']==0 and account['empty_password_entries']==0
assert all(v['all_locked'] and v['hash_material_entries']==0 for v in json.loads((E/'backup-password-review.json').read_text()).values())
pol=json.loads((E/'policy-text.json').read_text());trust=json.loads((E/'trust-inventory.json').read_text())
assert not trust['host_key_entries'] and not trust['root_ssh_exists']
assert all(k in pol['/etc/ssh/sshd_config.d/00-cm3-cli.conf'].splitlines() for k in ['PermitRootLogin no','PasswordAuthentication no','AuthenticationMethods publickey','AllowGroups cm3-cli-owner'])
assert not re.search(r'(?i)trusted\s*=\s*yes|allowunauthenticated|allowinsecurerepositories','\n'.join(v for p,v in pol.items() if p.startswith('/etc/apt/')))
assert 'debian-archive-keyring.pgp' in json.loads((E/'extra-metadata.json').read_text())['/usr/share/keyrings/debian-archive-keyring.gpg']
areas=[('embedded-private-keys','SCOPED EXCEPTION'),('build-credentials','STATIC PASS'),('developer-ssh-keys','STATIC PASS'),('password-credentials','STATIC PASS'),('account-policy','STATIC PASS'),('ssh-policy','STATIC PASS'),('sudo-policy','STATIC PASS'),('apt-config-trust','STATIC PASS'),('fresh-package-signatures','UNTESTED'),('apparmor-lsm-config','STATIC PASS'),('runtime-lsm','UNTESTED'),('identity-cleanup-provisioning','STATIC PASS'),('permissions','STATIC PASS')]
counts={v:sum(status==v for _,status in areas) for _,v in areas}
(E/'verdicts.json').write_text(json.dumps({'areas':[{'area':n,'verdict':v} for n,v in areas],'counts':counts,'runtime_pass':0,'defects_corrected':0,'hardware_status':'UNTESTED'},indent=2))
packet=W/'cm3-security-audit-evidence.zip'
paths=[p for p in E.iterdir() if p.is_file()]+[W/n for n in ['audit.py','supplement.py','key-provenance.py','coverage.py','finalize.py','security-audit-report.txt']]
# Never include the private rootfs, candidate review scratch script, raw keys or password values.
assert all(p.parent==E or p.parent==W for p in paths)
for p in paths:
 if p.suffix not in ['.py']:
  b=p.read_bytes()
  assert not re.search(rb'-----BEGIN ((?:RSA |DSA |EC |OPENSSH |ENCRYPTED )?PRIVATE KEY)-----\r?\n[A-Za-z0-9+/=\r\n]+-----END \1-----',b),p
  assert not re.search(rb'(?m)^root:[^:\n]*:[0-9]',b),p
up=pathlib.Path('/opt/data/kanban/workspaces/t_6c2ac45f/tool-downloads.json')
index={str(p.relative_to(W)):sha(p) for p in paths}
index['parent-tool-downloads.json']=sha(up)
with zipfile.ZipFile(packet,'w',zipfile.ZIP_DEFLATED) as z:
 for p in paths:z.write(p,str(p.relative_to(W)))
 z.write(up,'parent-tool-downloads.json')
 z.writestr('SHA256-index.json',json.dumps(index,indent=2))
with zipfile.ZipFile(packet) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(index)+1
 for n,h in index.items():assert hashlib.sha256(z.read(n)).hexdigest()==h,n
result={'packet_path':str(packet),'packet_sha256':sha(packet),'packet_bytes':packet.stat().st_size,'indexed_files':len(index),'zip_crc_and_member_sha256':'PASS','originals_final_hashes_unchanged':True,'requirement_verdict_counts':counts,'complete_private_test_vector_blocks':8,'runtime_executed':False,'hardware_status':'UNTESTED','sanitization_checks':'No password database contents, complete PEM blocks, raw rootfs, key hashes or credential snippets included.'}
(W/'packet-verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
