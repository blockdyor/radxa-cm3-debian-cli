import pathlib,json,re,zipfile,tarfile,io,ast,hashlib
W=pathlib.Path(__file__).resolve().parent;R=W/'private-root';E=W/'evidence'
lib=(R/'usr/lib/aarch64-linux-gnu/libgnutls.so.30.40.3').read_bytes()
pat=rb'-----BEGIN ((?:RSA |DSA |EC |OPENSSH |ENCRYPTED )?PRIVATE KEY)-----\r?\n[A-Za-z0-9+/=\r\n]+-----END \1-----'
keys=[m.group() for m in re.finditer(pat,lib)]
matches={i:[] for i in range(len(keys))}
z=zipfile.ZipFile('/opt/data/artifacts/cm3-qualification/t_ce5ca21d/retained-image-sources.zip')
source='sources/debian-sources/gnutls28_3.8.9.orig.tar.xz'
with tarfile.open(fileobj=io.BytesIO(z.read(source)),mode='r:xz') as t:
 for member in t:
  if not member.isfile() or member.size>8*1024*1024:continue
  b=t.extractfile(member).read()
  if b'PRIVATE KEY' not in b:continue
  # Concatenate decoded C string literals; no target code executed.
  literals=[]
  for token in re.findall(rb'"(?:[^"\\]|\\.)*"',b):
   try:
    value=ast.literal_eval(token.decode('ascii'))
    if isinstance(value,str):literals.append(value.encode())
   except (ValueError,SyntaxError,UnicodeError):pass
  joined=b''.join(literals)
  for i,k in enumerate(keys):
   if k in b or k in joined:matches[i].append(member.name)
result={'library_path':'/usr/lib/aarch64-linux-gnu/libgnutls.so.30.40.3','complete_private_key_blocks':len(keys),'exact_matches_to_retained_upstream_source':[{'block_index':i,'source_paths':p} for i,p in matches.items()],'all_blocks_matched':all(matches.values()),'source_archive_path':source,'classification':'Public upstream self-test/test vectors, not deployment/build/developer credentials. Literal no-embedded-private-keys condition is NOT MET; no key values or key hashes disclosed.'}
(E/'gnutls-key-provenance.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
# Review assignments only as safe enum categories, never print their values.
review=[]
for row in json.loads((E/'assignment-leads.json').read_text()):
 path=row['path']
 categories={'/etc/nsswitch.conf':'NSS passwd database mapping','/etc/ssl/openssl.cnf':'packaged OpenSSL enrollment examples/default template','/etc/security/namespace.init':'shell getent passwd variable','/var/lib/dpkg/info/openssh-server.postinst':'debconf boolean variable','/var/lib/dpkg/info/openssh-server.config':'debconf boolean variable','/var/lib/dpkg/info/sudo.prerm':'shell account lookup variable'}
 assert path in categories
 review.append(dict(row,classification=categories[path]))
(E/'assignment-review.json').write_text(json.dumps(review,indent=2))
