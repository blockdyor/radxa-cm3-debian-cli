"""Summarize candidate classifications and image metadata without credential values."""
import pathlib,os,re,json,subprocess,hashlib
W=pathlib.Path(__file__).resolve().parent;os.chdir(W)
R=W/'private-root';E=W/'evidence';UP=pathlib.Path('/opt/data/kanban/workspaces/t_6c2ac45f')
def save(n,x):(E/n).write_text(json.dumps(x,indent=2))
def read(p):return (R/p.lstrip('/')).read_bytes()
def text(p):return read(p).decode()
env=dict(os.environ,LD_LIBRARY_PATH=str(UP/'tools/root/usr/lib/aarch64-linux-gnu'))
def dbg(c):
 r=subprocess.run([str(UP/'tools/root/usr/sbin/debugfs'),'-R',c,str(W/'rootfs.ext4')],capture_output=True,env=env);assert r.returncode==0
 return r.stdout.decode(errors='replace')
scan=json.loads((E/'secret-scan.json').read_text());classes=[]
for h in scan['hits']:
 b=read(h['path'])
 if h['category']=='private-key-header':
  # PEM serialized private keys require a newline-delimited body and footer.
  complete=re.findall(rb'-----BEGIN ((?:RSA |DSA |EC |OPENSSH |ENCRYPTED )?PRIVATE KEY)-----\r?\n[A-Za-z0-9+/=\r\n]+-----END \1-----',b)
  assert b.startswith(b'\x7fELF') or h['path']=='/usr/lib/file/magic.mgc'
  classes.append(dict(h,complete_private_key_blocks=len(complete),classification='COMPLETE BLOCK REQUIRES REVIEW' if complete else 'format-recognition literal in ELF or file magic; no complete PEM block'))
 else:
  assert h['path']=='/usr/share/perl/5.40.1/HTTP/Tiny.pm'
  # Verify only obvious placeholder credentials, do not publish matched bytes.
  matches=re.findall(rb'https?://([^\s/:<>"\']+):([^\s/@<>"\']+)@',b)
  save('url-candidate-review.json',{'path':h['path'],'count':len(matches),'all_user_password_placeholders':all(a in [b'user',b'username'] and p in [b'pass',b'password'] for a,p in matches)})
  classes.append(dict(h,classification='HTTP::Tiny documentation/example URL; credential values withheld'))
save('candidate-review.json',classes)
backup={}
for path in ['/etc/shadow-','/etc/gshadow-']:
 rows=[r.split(':') for r in text(path).splitlines()]
 backup[path]={'entries':len(rows),'all_locked':all(r[1].startswith(('!','*')) for r in rows),'hash_material_entries':sum(bool(re.search(r'\$[0-9a-z]+\$',r[1])) for r in rows)}
save('backup-password-review.json',backup)
# Broad secret-assignment leads in mutable/configuration locations. Report names only.
pat=re.compile(rb'(?im)^\s*["\']?([A-Za-z0-9_.-]*(?:password|passwd|token|secret|api[_-]?key)[A-Za-z0-9_.-]*)["\']?\s*[:=]\s*([^\r\n]+)')
leads=[]
for prefix in ['etc','root','home','var','opt','run']:
 for base,dirs,files in os.walk(R/prefix,followlinks=False):
  dirs[:]=[d for d in dirs if not (pathlib.Path(base)/d).is_symlink()]
  for n in files:
   f=pathlib.Path(base)/n
   if f.is_symlink() or not f.is_file():continue
   b=f.read_bytes()
   if b'\0' in b:continue
   m=pat.findall(b)
   if m:leads.append({'path':'/'+str(f.relative_to(R)),'field_names':[x[0].decode(errors='replace') for x in m],'count':len(m)})
save('assignment-leads.json',leads)
# Explicit image symlink/ownership checks include all sensitive config parents.
paths=['/usr/share/keyrings/debian-archive-keyring.gpg','/usr/share/keyrings/debian-archive-keyring.pgp','/etc/apt','/etc/apt/apt.conf.d','/etc/apt/sources.list.d','/etc/apt/trusted.gpg.d','/etc/shadow-','/etc/gshadow-','/etc/ssh/sshd_config.d/00-cm3-cli.conf','/usr/lib/cm3-cli/enroll.py','/etc/systemd/system/ssh.service.d/cm3-cli.conf']
save('extra-metadata.json',{p:dbg('stat '+json.dumps(p)) for p in paths})
# Summaries narrow enough for reviewers to inspect without the large profile corpus.
policy={}
for path in ['/usr/lib/systemd/system/cm3-cli-enroll.service','/usr/lib/systemd/system/cm3-cli-firewall.service','/usr/lib/systemd/system/ssh.service','/etc/cm3-cli/nftables.conf','/etc/default/ssh','/etc/default/apparmor']:
 f=R/path.lstrip('/')
 if f.is_file():policy[path]=f.read_text()
policy['sudo_group_members']=[l.split(':')[3] for l in text('/etc/group').splitlines() if l.startswith('sudo:')]
policy['profile_mode_summary']={k:sum(k in f.read_text(errors='replace') for f in (R/'etc/apparmor.d').iterdir() if f.is_file() and not f.is_symlink()) for k in ['flags=(unconfined)','flags=(complain','flags=(enforce']}
policy['sshd_named_profile_files']=[f.name for f in (R/'etc/apparmor.d').iterdir() if 'ssh' in f.name.lower()]
policy['nonempty_log_paths']=[str(f.relative_to(R)) for f in (R/'var/log').rglob('*') if f.is_file() and not f.is_symlink() and f.stat().st_size]
save('policy-summary.json',policy)
print(json.dumps({'classified_hits':len(classes),'assignment_leads':leads,'backup_password_summary':backup,'url_review':json.loads((E/'url-candidate-review.json').read_text())}))
