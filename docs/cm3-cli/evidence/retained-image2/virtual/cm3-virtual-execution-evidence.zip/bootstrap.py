"""Re-fetch exact recorded Debian tools into this workspace only."""
from pathlib import Path
import os,json,hashlib,urllib.request,subprocess
W=Path(__file__).resolve().parent;os.chdir(W)
T=W/'tools';T.mkdir(exist_ok=True)
for p in json.loads(Path('tool-manifest.json').read_text()):
 dest=T/Path(p['Filename']).name
 assert not dest.is_symlink()
 if not dest.exists():urllib.request.urlretrieve('https://deb.debian.org/debian/'+p['Filename'],dest)
 assert hashlib.sha256(dest.read_bytes()).hexdigest()==p['SHA256'],dest
 subprocess.run(['dpkg-deb','-x',str(dest),str(T/'root')],check=True)
print('Exact recorded tool payloads downloaded/hash-checked/extracted; no host package installation')
