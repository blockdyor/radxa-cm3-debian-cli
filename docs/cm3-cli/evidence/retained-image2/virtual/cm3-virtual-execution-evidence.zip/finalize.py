from pathlib import Path
import os,json,re,hashlib,subprocess,zipfile,collections,platform,datetime
W=Path(__file__).resolve().parent;os.chdir(W)
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
R=Path('/opt/data/artifacts/cm3-qualification/t_ce5ca21d')
expected={'cm3-trixie-arm64-cli.img':'b0d1f56240fafc49cc32ceab0f041d4bb6f529604635684135ccc6ad26ebbff8','cm3-trixie-arm64-cli.img.xz':'6b72f1005c517309e9647e7c65d2344ee31e013da0e2f4ae5a07c4f2afcd8037','retained-image-sources.zip':'cac0f8575b91529e4809d86a99fb460b2279acc19fd8eea56469dca51d959fad'}
after={k:sha(R/k) for k in expected};assert after==expected
Path('retained-identities-after.json').write_text(json.dumps(after,indent=2))
# Final full-system run was explicitly stopped via process_manage after repeated
# service timeouts. Do not inherit numeric124 from an earlier attempt.
Path('virtual-exit.txt').write_text('INTERRUPTED via process_manage; final child numeric exit not recorded. Earlier attempt2 timed out124.\n')
def clean(s):return re.sub(r'\x1b(?:\[[0-?]*[ -/]*[@-~]|\][^\x07]*\x07|.)','',s).replace('\r','\n')
d=clean(Path('direct-console.log').read_text(errors='replace'));v=clean(Path('virtual-console.log').read_text(errors='replace'))
Path('direct-console-clean.txt').write_text(d);Path('virtual-console-clean.txt').write_text(v)
probes=[]
for m in re.finditer(r'^PROBE ([^\n]*)\n(.*?)(?=^PROBE |\Z)',d,re.M|re.S):
 exits=re.findall(r'EXIT (\d+)',m[2]);probes.append({'command':m[1],'exit':int(exits[0]) if exits else None,'output':m[2].strip()})
Path('direct-probe-results.json').write_text(json.dumps(probes,indent=2))
assert probes and all(p['exit'] is not None for p in probes)
assert Path('direct-exit.txt').read_text().strip()=='0'
assert all(x in d for x in ['CM3_DIRECT_SECOND_BOOT_BEGIN','/etc/machine-id: OK','/etc/ssh/ssh_host_ecdsa_key.pub: OK','/etc/ssh/ssh_host_ed25519_key.pub: OK','/etc/ssh/ssh_host_rsa_key.pub: OK','reboot: Power down'])
checks=[]
def add(name,status,detail):checks.append({'area':name,'status':status,'detail':detail})
add('retained kernel boot','NOT APPLICABLE','Attempted virt boot exited0 with empty console; no successful retained-kernel execution established. Retained config disables PL011 and virtio blk/net/MMIO. Real CM3 boot UNTESTED.')
add('retained userspace execution','PASS','Actual retained Bash/tools executed as PID1 on alternate6.12.107 cloud kernel; direct QEMU exits0 after two boots.')
add('full systemd runtime','FAIL','Retained systemd257 PID1 actually started on alternate kernel; SSH generator exit1, journald/time-sync/device timeouts occurred. Full run interrupted after repeated timeout evidence. No multi-user/healthy-services claim; TCG limitation, not established CM3 defect.')
add('systemd enabled configuration','STATIC PASS','Retained systemctl --root=/ is-enabled returns0 and three enabled entries. Offline configuration only, not service startup.')
add('systemd unit verify','FAIL','Retained systemd-analyze verify exits1 solely with two reported man sshd/sshd_config documentation-command failures in direct log; not a clean verify PASS.')
add('package manager operation','PASS','Retained dpkg --audit, apt-get check and apt-get -s install bash all exit0. No package upgrade/install or fresh repository signature verification demonstrated.')
add('virtual interface/address/routes','PASS','Preloaded virtio-net and harness static10.0.2.15/24/default route observed by retained ip; not DHCP/NetworkManager or hardware Ethernet qualification.')
add('DNS resolution','FAIL','Actual getent ahostsv4 deb.debian.org exits2 under restrict=on slirp. Successful DNS not established.')
add('APT repository refresh','FAIL','Actual timeout25 apt-get update reports temporary DNS failures and returns124. Restricted-network outcome, not an established APT-source defect.')
add('first-boot enrollment offboard rejection','PASS','Actual retained enroll.py and --check each exit1 with SSH-gated diagnostic. No owner config/CM3 DTB supplied; no enrollment success or account creation claimed.')
add('successful target enrollment','NOT APPLICABLE','QEMU virt is not the required CM3 target. Installed guard not patched or bypassed.')
add('SSH preidentity rejection','PASS','sshd -t exits1 with no hostkeys available before explicit generation.')
add('SSH identities and configuration','PASS','Actual timeout120 ssh-keygen -A exits0 generating RSA/ECDSA/ED25519; subsequent retained sshd -t exits0.')
add('SSH daemon startup','PASS','Direct loopback-only sshd writes Server listening on127.0.0.1 port2222; signal15 terminates cleanly. Not the gated systemd SSH service.')
add('SSH handshake/authenticated login','FAIL','ssh-keyscan exits1; no handshake or owner authentication established. A startup race is possible, not proven; listening evidence is separate.')
add('machine identity creation','PASS','Actual systemd-machine-id-setup exits0 and detects nonempty machine-id. Alternate-kernel direct-init path only.')
add('identity persistence across reboot','PASS','Second direct boot verifies machine-id and all three host public-key checksums unchanged, exit0. Does not establish cross-device uniqueness.')
add('log creation','PASS','Actual sshd writes nonempty /var/log/cm3-direct-sshd.log, printed by retained cat. Host serial capture retains all probe results.')
add('probe file tee/journal completeness','FAIL','Direct Bash tee redirection fails /dev/fd/63 absent; combined probe-log assertion exits1. Serial capture is authoritative. Full-system journald timed out; no durable journal PASS.')
add('forced kernel reboot/poweroff','PASS','Direct PID1 calls reboot -ff, boots again, verifies identities, then poweroff -ff; console shows Restarting system and Power down, QEMU exits0.')
add('systemd reboot/shutdown ordering','NOT APPLICABLE','Full-system probe service did not reach its reboot markers. Direct forced kernel calls explicitly do not validate systemd ordering.')
add('root expansion entry point','NOT APPLICABLE','Retained project has no implemented root-expansion script; parent lifecycle evidence confirms gap. No generic grower substituted; hardware expansion remains unmet/UNTESTED.')
add('alternate-kernel AppArmor activation','PASS','Actual /sys/kernel/security/lsm includes apparmor and aa-status --enabled exits0 on cloud kernel. Not retained-kernel activation or profile/service-confinement proof.')
add('physical CM3/CmRat qualification','UNTESTED','All original28physical matrix statuses remain UNTESTED; no real storage/device passthrough, RK3566 DTB/U-Boot/DRAM/peripheral/power-loss qualification.')
counts=dict(collections.Counter(c['status'] for c in checks));exits=dict(collections.Counter(str(p['exit']) for p in probes))
summary={'scope':'Not hardware qualification','built_commit':'2b41b830cae9efc313f3d39d85be265b6e3eae25','run_url':'https://github.com/blockdyor/radxa-cm3-debian-cli/actions/runs/41199013085','retained_hashes_after':after,'checks':checks,'verdict_counts':counts,'direct_command_count':len(probes),'direct_exit_histogram':exits,'direct_qemu_exit':0,'full_systemd_qemu_exit':'interrupted; no final numeric child exit','kernel_sha256':{'retained':sha('vmlinuz'),'alternate':sha('virtual-kernel')},'copy_hashes_after':{n:sha(n) for n in ['direct-root.ext4','vm-root.ext4','vm-fat1.img','vm-fat2.img']},'repository_changes':False,'rebuilds':0,'defects_corrected':0,'host':platform.platform(),'canonical_context':'entities/blockdyor.md and SCHEMA.md delegate CM3 engineering state to existing Kanban/GitHub; existing task handoff updated, no duplicate Obsidian task or unsupported sync claim.'}
Path('virtual-validation-results.json').write_text(json.dumps(summary,indent=2))
# Read metadata only from copied images. Never dump generated private key values.
env=dict(os.environ,LD_LIBRARY_PATH=str(W/'tools/root/usr/lib/aarch64-linux-gnu'))
meta=[]
for target in ['direct-root.ext4','vm-root.ext4']:
 for path in ['/etc/machine-id','/etc/ssh','/var/log','/var/log/journal','/var/lib/cm3-direct-reboot']:
  cmd='ls -p '+path if path in ['/etc/ssh','/var/log','/var/log/journal'] else 'stat '+path
  r=subprocess.run([str(W/'tools/root/usr/sbin/debugfs'),'-R',cmd,target],env=env,capture_output=True,text=True)
  meta.append({'image':target,'command':cmd,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
Path('copy-generated-file-metadata.json').write_text(json.dumps(meta,indent=2))
report=['CM3 VIRTUAL VALIDATION — SCOPED EVIDENCE, NOT HARDWARE QUALIFICATION',datetime.datetime.now(datetime.timezone.utc).isoformat(),'','Input commit '+summary['built_commit'],summary['run_url'],*[k+' SHA256 '+val for k,val in after.items()],'','All three retained originals rehashed unchanged after execution. Tested VM disks are deliberately modified disposable partition copies, NOT byte-identical original images. Copy hashes and injected commands are recorded in JSON/text. No repository change, product rebuild, remedial fix or physical storage operation.','','Execution: QEMU10.0.13 virt/Cortex-A53 TCG. Alternate Debian6.12.107 cloud kernel, custom initramfs/preloaded matching modules. Separate full retained-systemd path and successful two-boot retained-Bash/direct-tool path. No KVM; namespace creation denied. See REPRODUCE.txt/tool-manifest.json for exact commands, versions, network restrictions and replay.','','Checks: '+json.dumps(counts,sort_keys=True),'Direct actual probe commands: '+str(len(probes))+'; raw exit histogram '+json.dumps(exits,sort_keys=True)+'. Nonzero exits include deliberate offboard/missing-identity rejection; these are not all product defects. Verdict counts refer to scoped evidence checks, not a conventional green test suite.','']
for c in checks:report.extend([c['status']+' — '+c['area'],c['detail'],''])
report.extend(['Harness limitations and attempt history:','Retained-kernel probe: QEMU exits0 but zero serial bytes; not a successful boot.','Attempt1: alternate cloud initramfs initially selected a FAT copy as root; mount invalid-argument then wall timeout. Corrected harness root ordering, not product.','Attempt2: reached actual systemd PID1 but timed out124 before probes, with matching cloud modules not yet staged.','Attempt3/4: interrupted preparation experiments; console files preserve partial output, no success verdict.','Final full-system run: cloud modules staged via native debugfs and depmod, retained systemd started but repeated journald/udev/device/time-sync timeouts prevented probe execution; explicitly stopped with process_manage, final child numeric status unavailable.','Final direct run: QEMU exit0 after actual commands, forced reboot, identity-persistence checks and poweroff. Direct probe tee redirection fails due missing /dev/fd symlink; serial log preserves outputs, daemon file log exists. Missing man pages make systemd-analyze verify nonzero. DNS and handshake are not established. These are disclosed findings, not silently replaced with fabricated PASS results.','','No retained product defect was corrected. Root expansion remains absent; service runtime failures under alternate-kernel TCG and harness limits are not sufficient to call the physical image defective. Experimental prerelease/hardware admission belongs to downstream consolidation, not this userspace report.','','Physical checklist: Rockchip boot chain/retained kernel, DRAM/DTB/UART, SD/eMMC/NVMe/USB selection and real expansion, network PHY/Wi-Fi, thermal/load/power behaviour, recovery and physical reboot/power-loss remain UNTESTED. All original28hardware rows stay unchanged.','','Canonical context: Obsidian entities/blockdyor.md and SCHEMA.md retain identity/index, original source Kanban/GitHub. Current engineering evidence is this existing task handoff; no duplicate note or sync completion claimed.'])
Path('virtual-validation-report.txt').write_text('\n'.join(report)+'\n')
include=['REPRODUCE.txt','bootstrap.py','prepare-inputs.py','probe-vm.py','run-virtual.py','run-virtual-executed.py','run-direct.py','guest-direct.sh','guest-probes.sh','finalize.py','tool-manifest.json','preflight.json','expectations.json','retained-identities-after.json','virtual-validation-results.json','virtual-validation-report.txt','copy-generated-file-metadata.json','direct-probe-results.json','depmod-command.json','setup-tools.log','retained-probe-command.json','retained-probe.log','retained-probe-exit.txt','image-copy-modifications.txt','image-modification.log','direct-copy-modifications.txt','direct-modification.log','direct-command.json','direct-console.log','direct-console-clean.txt','direct-exit.txt','direct-init.txt','virtual-command.json','virtual-console.log','virtual-console-clean.txt','virtual-exit.txt','virtual-console-attempt1.log','virtual-console-attempt2.log','virtual-console-attempt3-interrupted.log','virtual-console-attempt4-interrupted.log','inputs/partitions.json']
manifest={n:sha(n) for n in include};Path('packet-manifest.json').write_text(json.dumps(manifest,indent=2))
with zipfile.ZipFile('cm3-virtual-execution-evidence.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
 for n in include+['packet-manifest.json']:z.write(n,n)
with zipfile.ZipFile('cm3-virtual-execution-evidence.zip') as z:
 assert z.testzip() is None
 for n,h in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==h,n
verification={'packet_sha256':sha('cm3-virtual-execution-evidence.zip'),'indexed_files':len(manifest),'zip_crc_and_all_member_hashes':'PASS','originals_unchanged':True,'direct_actual_commands':len(probes),'verdict_counts':counts}
Path('packet-verification.json').write_text(json.dumps(verification,indent=2));print(json.dumps(verification,indent=2))
