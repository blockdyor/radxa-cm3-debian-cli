#!/bin/bash
# Disposable QEMU direct-init probes; deliberately NOT a systemd boot.
set -u
exec > >(tee /var/log/cm3-direct-probes.log /dev/ttyAMA0) 2>&1
run() { printf '\nPROBE'; printf ' %q' "$@"; printf '\n'; "$@"; rc=$?; echo "EXIT $rc"; }
if [ -e /var/lib/cm3-direct-reboot ]; then
 echo CM3_DIRECT_SECOND_BOOT_BEGIN
 run sha256sum -c /var/log/cm3-direct-identities-before.txt
 echo CM3_DIRECT_KERNEL_POWEROFF
 sync
 /sbin/poweroff -ff
fi
echo CM3_DIRECT_PROBES_BEGIN
run uname -a
run systemctl --root=/ is-enabled cm3-cli-enroll.service ssh.service NetworkManager.service
run systemd-analyze verify /usr/lib/systemd/system/cm3-cli-enroll.service /usr/lib/systemd/system/ssh.service
run dpkg --audit
run apt-get check
run apt-get -s install bash
run ip -brief address
run ip route
run getent ahostsv4 deb.debian.org
run timeout 25 apt-get -o Acquire::Retries=0 -o Acquire::http::Timeout=5 -o Acquire::https::Timeout=5 -o APT::Update::Error-Mode=any update
run /usr/lib/cm3-cli/enroll.py
run /usr/lib/cm3-cli/enroll.py --check
mkdir -p /run/sshd
run /usr/sbin/sshd -t
run timeout 120 ssh-keygen -A
run /usr/sbin/sshd -t
/usr/sbin/sshd -D -e -p 2222 -o ListenAddress=127.0.0.1 > /var/log/cm3-direct-sshd.log 2>&1 &
sshd_pid=$!
sleep 2
run ssh-keyscan -T 15 -p 2222 127.0.0.1
kill "$sshd_pid" 2>/dev/null
wait "$sshd_pid"; echo "SSHD_WAIT_EXIT $?"
run cat /var/log/cm3-direct-sshd.log
run systemd-machine-id-setup
run sh -c 'test -s /etc/machine-id && echo MACHINE_ID_PRESENT'
run cat /sys/kernel/security/lsm
run aa-status --enabled
run sh -c 'for f in /etc/ssh/ssh_host_*_key.pub; do ssh-keygen -lf "$f"; done'
sha256sum /etc/machine-id /etc/ssh/ssh_host_*_key.pub > /var/log/cm3-direct-identities-before.txt
run sh -c 'test -s /var/log/cm3-direct-sshd.log && test -s /var/log/cm3-direct-probes.log'
touch /var/lib/cm3-direct-reboot
echo CM3_DIRECT_KERNEL_REBOOT
sync
/sbin/reboot -ff
