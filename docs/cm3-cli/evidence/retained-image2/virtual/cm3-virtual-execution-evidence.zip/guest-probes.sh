#!/bin/bash
# Runs only inside QEMU's disposable root, never on the host.
set -u
exec > >(tee /var/log/cm3-virtual-probes.log /dev/ttyAMA0) 2>&1
run() { printf '\nPROBE'; printf ' %q' "$@"; printf '\n'; "$@"; rc=$?; echo "EXIT $rc"; }
echo 'CM3_VIRTUAL_PROBES_BEGIN'
run uname -a
run systemctl is-system-running
run systemctl --failed --no-pager
run systemctl show cm3-cli-enroll.service ssh.service cm3-cli-firewall.service -p ActiveState -p SubState -p Result -p ExecMainStatus
run systemctl get-default
run aa-status --enabled
run cat /sys/kernel/security/lsm
run systemctl is-enabled cm3-cli-enroll.service ssh.service NetworkManager.service
run systemd-analyze verify /usr/lib/systemd/system/cm3-cli-enroll.service /usr/lib/systemd/system/ssh.service
run dpkg --audit
run apt-get check
run apt-get -s install bash
run ip -brief address
run ip route
run getent ahostsv4 deb.debian.org
run timeout 25 apt-get -o Acquire::Retries=0 -o Acquire::http::Timeout=5 -o Acquire::https::Timeout=5 -o APT::Update::Error-Mode=any update
run /usr/lib/cm3-cli/enroll.py
run /usr/lib/cm3-cli/enroll.py --check
run journalctl -b -u cm3-cli-enroll.service -u ssh.service --no-pager
run /usr/sbin/sshd -t
run ssh-keygen -A
run /usr/sbin/sshd -t
mkdir -p /run/sshd
/usr/sbin/sshd -D -e -p 2222 -o ListenAddress=127.0.0.1 > /var/log/cm3-virtual-sshd.log 2>&1 &
sshd_pid=$!
sleep 2
run ssh-keyscan -T 5 -p 2222 127.0.0.1
kill "$sshd_pid" 2>/dev/null
wait "$sshd_pid"; echo "SSHD_WAIT_EXIT $?"
run cat /var/log/cm3-virtual-sshd.log
run sh -c 'test -s /etc/machine-id && echo MACHINE_ID_PRESENT'
run sh -c 'for f in /etc/ssh/ssh_host_*_key.pub; do ssh-keygen -lf "$f"; done'
run journalctl --sync
run journalctl -b --no-pager -n 60
sha256sum /etc/machine-id /etc/ssh/ssh_host_*_key.pub > /var/log/cm3-virtual-identities-before.txt
echo 'CM3_VIRTUAL_PROBES_END_REBOOT'
touch /var/lib/cm3-virtual-reboot
systemctl reboot
