"""Extract regular-file partition copies; never open host block devices."""
from pathlib import Path
import hashlib,struct,json,os,stat
W=Path(__file__).resolve().parent;os.chdir(W)
R=Path(os.environ.get('CM3_RETAINED','/opt/data/artifacts/cm3-qualification/t_ce5ca21d'))
raw=R/'cm3-trixie-arm64-cli.img'
assert stat.S_ISREG(raw.stat().st_mode) and not raw.is_symlink()
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert sha(raw)=='b0d1f56240fafc49cc32ceab0f041d4bb6f529604635684135ccc6ad26ebbff8'
I=W/'inputs';I.mkdir(exist_ok=True)
rows=[]
with raw.open('rb') as f:
 f.seek(512);header=f.read(512);assert header[:8]==b'EFI PART'
 entries,n,size=struct.unpack_from('<QII',header,72)
 assert size==128 and n<=4096
 f.seek(entries*512);table=f.read(n*size)
 for idx in range(3):
  e=table[idx*size:(idx+1)*size];first,last=struct.unpack_from('<QQ',e,32)
  assert first>0 and last>=first and (last+1)*512<=raw.stat().st_size
  dest=I/('rootfs.ext4' if idx==2 else f'fat{idx+1}.img')
  assert not dest.is_symlink()
  with dest.open('wb') as out:
   f.seek(first*512);remaining=(last-first+1)*512
   while remaining:
    b=f.read(min(8*1024*1024,remaining));assert b;out.write(b);remaining-=len(b)
  rows.append({'number':idx+1,'first_lba':first,'last_lba':last,'copy_sha256':sha(dest)})
(I/'partitions.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
