from pathlib import Path
import os,subprocess,json,hashlib,shutil
W=Path(__file__).resolve().parent;os.chdir(W)
P=W/'inputs'
env=dict(os.environ,LD_LIBRARY_PATH=str(W/'tools/root/usr/lib/aarch64-linux-gnu'))
dbg=str(W/'tools/root/usr/sbin/debugfs')
for name in ['vmlinuz','config']:
 target=f'/boot/{name}-6.1.84-18+cm3cli1-rk2410-nocsf'
 r=subprocess.run([dbg,'-R',f'dump {target} {name}',str(P/'rootfs.ext4')],env=env,capture_output=True,text=True);print(r.returncode,r.stderr)
print('\n'.join(l for l in Path('config').read_text().splitlines() if any(x in l for x in ['VIRTIO','PL011','ARCH_VIRT','ARM_GIC','PCI_HOST_GENERIC'])))
if not Path('vm-root.ext4').exists():shutil.copyfile(P/'rootfs.ext4','vm-root.ext4')
qenv=dict(os.environ,LD_LIBRARY_PATH=str(W/'tools/root/usr/lib/aarch64-linux-gnu'))
args=[str(W/'tools/root/usr/bin/qemu-system-aarch64'),'-M','virt','-cpu','cortex-a53','-accel','tcg,thread=multi','-m','768','-smp','2','-nographic','-monitor','none','-nic','none','-kernel','vmlinuz','-append','console=ttyAMA0 earlycon root=/dev/vda rw init=/bin/sh panic=-1','-drive','file=vm-root.ext4,format=raw,if=none,id=root','-device','virtio-blk-device,drive=root','-no-reboot']
Path('retained-probe-command.json').write_text(json.dumps(args,indent=2))
with open('retained-probe.log','w') as log:
 try:r=subprocess.run(args,input='echo CM3_SHELL_EXECUTED\nuname -a\ncat /etc/os-release\n/sbin/poweroff -f\n',env=qenv,stdout=log,stderr=subprocess.STDOUT,text=True,timeout=150);code=r.returncode
 except subprocess.TimeoutExpired:code=124
Path('retained-probe-exit.txt').write_text(str(code));print('qemu exit',code)
