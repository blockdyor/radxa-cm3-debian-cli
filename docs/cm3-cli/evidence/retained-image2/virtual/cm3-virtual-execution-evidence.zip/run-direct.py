"""Fallback actual retained-userspace execution without systemd as PID1."""
from pathlib import Path
import os,json,subprocess,shutil,gzip
W=Path(__file__).resolve().parent;os.chdir(W);T=W/'tools';P=W/'inputs'
env=dict(os.environ,LD_LIBRARY_PATH=str(T/'root/usr/lib/aarch64-linux-gnu'))
I=W/'initramfs'
init='''#!/bin/busybox sh
/bin/busybox --install -s /bin
mount -t devtmpfs devtmpfs /dev
mount -t proc proc /proc
mount -t sysfs sysfs /sys
'''+''.join('insmod /modules/'+n+'.ko\n' for n in ['virtio_mmio','virtio_blk','failover','net_failover','virtio_net'])+'''sleep 2
mount -t ext4 -o rw /dev/vda /newroot || exec sh
mount --move /dev /newroot/dev
mount --move /proc /newroot/proc
mount --move /sys /newroot/sys
mount -t tmpfs tmpfs /newroot/run
mkdir -p /newroot/dev/pts /newroot/sys/kernel/security
mount -t devpts devpts /newroot/dev/pts
mount -t securityfs securityfs /newroot/sys/kernel/security
ip link set lo up
ip link set eth0 up
ip addr add 10.0.2.15/24 dev eth0
ip route add default via 10.0.2.2
exec switch_root /newroot /bin/bash /usr/local/sbin/cm3-direct-probes
'''
def entry(name,data,mode,ino):
 values=[ino,mode,0,0,1,0,len(data),0,0,0,0,len(name.encode())+1,0]
 out=b'070701'+b''.join(f'{v:08x}'.encode() for v in values)+name.encode()+b'\0';out+=bytes(-len(out)%4);out+=data;return out+bytes(-len(out)%4)
archive=b''
for ino,f in enumerate([I,*sorted(I.rglob('*'))],1):
 name='.' if f==I else str(f.relative_to(I));data=b'' if f.is_dir() else (init.encode() if name=='init' else f.read_bytes())
 archive+=entry(name,data,f.stat().st_mode,ino)
archive+=entry('TRAILER!!!',b'',0,99999)
Path('direct-initramfs.cpio.gz').write_bytes(gzip.compress(archive,mtime=0));Path('direct-init.txt').write_text(init)
assert not Path('direct-root.ext4').is_symlink()
shutil.copyfile(P/'rootfs.ext4','direct-root.ext4')
Path('direct-resolv.conf').write_text('nameserver 10.0.2.3\noptions timeout:2 attempts:1\n')
cmds=['write guest-direct.sh /usr/local/sbin/cm3-direct-probes','rm /etc/resolv.conf','write direct-resolv.conf /etc/resolv.conf']
Path('direct-copy-modifications.txt').write_text('\n'.join(cmds))
with open('direct-modification.log','w') as log:
 subprocess.run([str(T/'root/usr/sbin/debugfs'),'-w','-f','direct-copy-modifications.txt','direct-root.ext4'],env=env,check=True,stdout=log,stderr=subprocess.STDOUT)
args=[str(T/'root/usr/bin/qemu-system-aarch64'),'-M','virt','-cpu','cortex-a53','-accel','tcg,thread=single','-m','512','-smp','1','-nographic','-monitor','none','-kernel','virtual-kernel','-initrd','direct-initramfs.cpio.gz','-append','console=ttyAMA0 apparmor=1 security=apparmor','-drive','file=direct-root.ext4,format=raw,if=none,id=root','-device','virtio-blk-device,drive=root','-netdev','user,id=net0,restrict=on','-device','virtio-net-device,netdev=net0']
Path('direct-command.json').write_text(json.dumps(args,indent=2))
with open('direct-console.log','w') as log:
 try:r=subprocess.run(args,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,timeout=1500);code=r.returncode
 except subprocess.TimeoutExpired:code=124
Path('direct-exit.txt').write_text(str(code));print('direct exit',code)
