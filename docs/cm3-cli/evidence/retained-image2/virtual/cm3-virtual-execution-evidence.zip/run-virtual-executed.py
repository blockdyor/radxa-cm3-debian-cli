from pathlib import Path
import os,subprocess,json,gzip,hashlib,shutil,stat
W=Path(__file__).resolve().parent;os.chdir(W);P=W/'inputs'
T=W/'tools'; env=dict(os.environ,LD_LIBRARY_PATH=str(T/'root/usr/lib/aarch64-linux-gnu'))
# Tool retrieval uses Debian HTTPS and index SHA256, not a new signed Release verification.
packages=json.loads((W/'tool-manifest.json').read_text());p=next(p for p in packages if p['Package']=='busybox-static')
import urllib.request
f=T/Path(p['Filename']).name
if not f.exists():urllib.request.urlretrieve('https://deb.debian.org/debian/'+p['Filename'],f)
assert hashlib.sha256(f.read_bytes()).hexdigest()==p['SHA256']
subprocess.run(['dpkg-deb','-x',str(f),str(T/'root')],check=True)
(T/'busybox-origin.json').write_text(json.dumps(p,indent=2))
K='6.12.107+deb13-cloud-arm64'
b=(T/f'root/boot/vmlinuz-{K}').read_bytes()
Path('virtual-kernel').write_bytes(gzip.decompress(b) if b[:2]==b'\x1f\x8b' else b)
I=W/'initramfs';I.mkdir(exist_ok=True)
for d in ['bin','dev','proc','sys','newroot','modules']: (I/d).mkdir(exist_ok=True)
shutil.copyfile(T/'root/usr/bin/busybox',I/'bin/busybox');(I/'bin/busybox').chmod(0o755)
mods=['virtio_mmio','virtio_blk','failover','net_failover','virtio_net']
for name in mods:
 found=list((T/f'root/usr/lib/modules/{K}').rglob(name+'.ko*'));assert len(found)==1,(name,found)
 src=found[0];data=src.read_bytes()
 if src.suffix=='.xz':
  import lzma
  data=lzma.decompress(data)
 (I/f'modules/{name}.ko').write_bytes(data)
init='''#!/bin/busybox sh
/bin/busybox --install -s /bin
mount -t devtmpfs devtmpfs /dev
mount -t proc proc /proc
mount -t sysfs sysfs /sys
'''+''.join('insmod /modules/'+n+'.ko\n' for n in mods)+'''sleep 2
mount -t ext4 -o rw /dev/vdc /newroot || exec sh

mount --move /dev /newroot/dev
mount --move /proc /newroot/proc
mount --move /sys /newroot/sys
exec switch_root /newroot /sbin/init
'''
(I/'init').write_text(init);(I/'init').chmod(0o755)
def entry(name,data,mode,ino):
 values=[ino,mode,0,0,1,0,len(data),0,0,0,0,len(name.encode())+1,0]
 out=b'070701'+b''.join(f'{v:08x}'.encode() for v in values)+name.encode()+b'\0';out+=bytes(-len(out)%4);out+=data;return out+bytes(-len(out)%4)
assert entry('test',b'abc',0o100644,1).startswith(b'070701')
archive=b''
for ino,f in enumerate([I,*sorted(I.rglob('*'))],1):
 name='.' if f==I else str(f.relative_to(I));archive+=entry(name,b'' if f.is_dir() else f.read_bytes(),f.stat().st_mode,ino)
archive+=entry('TRAILER!!!',b'',0,99999)
Path('virtual-initramfs.cpio.gz').write_bytes(gzip.compress(archive,mtime=0))
shutil.copyfile(P/'rootfs.ext4','vm-root.ext4')
dbg=str(T/'root/usr/sbin/debugfs');denv=env
service='''[Unit]
Description=Disposable QEMU probe only; not a shipped CM3 unit
After=network.target
[Service]
Type=oneshot
ExecStart=/bin/bash /usr/local/sbin/cm3-virtual-entry
TimeoutStartSec=240
[Install]
WantedBy=multi-user.target
'''
Path('probe.service').write_text(service)
Path('guest-entry.sh').write_text('''#!/bin/bash
sleep 12
if [ -e /var/lib/cm3-virtual-reboot ]; then
 echo CM3_SECOND_BOOT_BEGIN > /dev/ttyAMA0
 sha256sum -c /var/log/cm3-virtual-identities-before.txt > /dev/ttyAMA0 2>&1
 journalctl -b -1 -n 30 --no-pager > /dev/ttyAMA0 2>&1
 echo CM3_SECOND_BOOT_ORDERLY_POWEROFF > /dev/ttyAMA0
 systemctl poweroff
else
 /bin/bash /usr/local/sbin/cm3-virtual-probes
fi
''')
cmds=['mkdir /usr/local/sbin','mkdir /var/log/journal','mkdir /run/sshd',
'write guest-probes.sh /usr/local/sbin/cm3-virtual-probes','write guest-entry.sh /usr/local/sbin/cm3-virtual-entry','write probe.service /etc/systemd/system/cm3-virtual-probe.service',
'symlink /etc/systemd/system/multi-user.target.wants/cm3-virtual-probe.service /etc/systemd/system/cm3-virtual-probe.service']
subprocess.run([str(T/'root/usr/sbin/depmod'),'-b',str(T/'root'),'-m','/usr/lib/modules',K],env=env,check=True)
module_root=T/f'root/usr/lib/modules/{K}'
for source in [module_root,*sorted(module_root.rglob('*'))]:
 target='/usr/lib/modules/'+str(source.relative_to(module_root.parent))
 if source.is_dir():cmds.append('mkdir '+target)
 elif source.is_file():cmds.append('write '+str(source)+' '+target)
 else:raise ValueError('Unexpected module path '+str(source))
Path('image-copy-modifications.txt').write_text('\n'.join(cmds))
with open('image-modification.log','w') as log:
 r=subprocess.run([dbg,'-w','-f','image-copy-modifications.txt','vm-root.ext4'],env=denv,stdout=log,stderr=subprocess.STDOUT);assert r.returncode==0
for num in [1,2]:shutil.copyfile(P/f'fat{num}.img',f'vm-fat{num}.img')
args=[str(T/'root/usr/bin/qemu-system-aarch64'),'-M','virt','-cpu','cortex-a53','-accel','tcg,thread=single','-m','768','-smp','1','-nographic','-monitor','none','-kernel','virtual-kernel','-initrd','virtual-initramfs.cpio.gz','-append','console=ttyAMA0 root=/dev/vdc rw apparmor=1 security=apparmor systemd.log_target=console systemd.mask=serial-getty@ttyFIQ0.service',
'-drive','file=vm-root.ext4,format=raw,if=none,id=root','-device','virtio-blk-device,drive=root',
'-drive','file=vm-fat1.img,format=raw,if=none,id=fat1','-device','virtio-blk-device,drive=fat1',
'-drive','file=vm-fat2.img,format=raw,if=none,id=fat2','-device','virtio-blk-device,drive=fat2',
'-netdev','user,id=net0,restrict=on','-device','virtio-net-device,netdev=net0']
Path('virtual-command.json').write_text(json.dumps(args,indent=2))
with open('virtual-console.log','w') as log:
 try:r=subprocess.run(args,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,timeout=1800);code=r.returncode
 except subprocess.TimeoutExpired:code=124
Path('virtual-exit.txt').write_text(str(code));print('virtual exit',code)
